import { useEffect, useMemo, useRef, useState } from 'react'
import {
  MAP_W, MAP_H, DEFAULT_ZOOM, MIN_ZOOM, MAX_ZOOM, WHEEL_ZOOM_INTENSITY,
  DRAG_THRESHOLD_PX, MIN_SIZE, STYLE_PRESETS,
  TERRAIN_TYPES, TOOLS, POINT_DRAW_TOOLS, MAP_TYPE_TOOLS, STAMP_LIBRARY,
  LOCATION_ICON_OPTIONS, MAP_FONT_OPTIONS, MAP_TYPE_OPTIONS, SCHEMA_VERSION,
  territoryNounFor, territoryNounPluralFor, DEFAULT_GRID_SCALES,
} from './mapConstants.js'
import {
  uid, clamp, round, screenToMap, snapToGrid,
  objectContainsPoint, normalizeObject, loadJson, saveJson, getObjectBounds, isMapObjectExportable,
} from './mapUtils.js'
import { downloadBlob } from '../../utils/projectExportHelpers.js'
import { drawBackground, drawMovementGrid, drawObject, drawDraft, drawHoverHighlight, drawRiverGroup } from './mapDraw.js'

// ─── Constants ────────────────────────────────────────────────────────────────

const PANEL_W = 260
const TOOLBAR_W = 88
const CMD_H = 48

const STYLE_SWATCHES = {
  parchment: '#e8d6a4',
  atlas: '#b4cfd8',
  campaign: '#e4d9c4',
  blueprint: '#1e2f50',
}

const MAP_TYPE_HELP = {
  world: 'Continents, oceans, and kingdoms',
  region: 'Territories, routes, and landmarks',
  local: 'Towns, islands, and battlefields',
  interior: 'Dungeons, buildings, and rooms',
}

const MAP_TYPE_ICON = {
  world: '◎',
  region: '◇',
  local: '⌂',
  interior: '▦',
}

// Line-type objects support per-segment selection: double-click picks the
// segment between two path points; Delete removes just that segment.
const LINE_SEGMENT_TYPES = new Set(['wall', 'river', 'road', 'path', 'border', 'mountain'])
const POLYGON_DRAW_TOOLS = new Set(['shape', 'terrain', 'region', 'water'])
const FREEHAND_DRAW_TOOLS = new Set(['shape', 'terrain', 'region', 'water', 'river', 'road', 'path', 'border'])
const CLOSED_POINT_DRAW_TOOLS = new Set(['shape', 'terrain', 'region', 'water'])
const INTERIOR_STAMP_CATEGORIES = new Set(['Furniture', 'Fixtures', 'Signifiers'])
const LOCAL_STAMP_CATEGORIES = new Set(['Local Structures', 'Local Features', 'Local Nature', 'Local Markers', 'Signifiers'])
const LOCAL_WALL_MATERIALS = [
  { value: 'grey-brick', label: 'Grey brick', stroke: '#62686b', highlight: '#aeb4b2', mortar: '#3e4447' },
  { value: 'beige-brick', label: 'Beige brick', stroke: '#b89f78', highlight: '#ead8b2', mortar: '#8f7652' },
  { value: 'white-brick', label: 'White brick', stroke: '#d9d9d2', highlight: '#ffffff', mortar: '#9a9a92' },
  { value: 'black-brick', label: 'Black brick', stroke: '#262626', highlight: '#545454', mortar: '#0f0f0f' },
  { value: 'red-brick', label: 'Red brick', stroke: '#9b4539', highlight: '#d27a64', mortar: '#5d2924' },
  { value: 'wood', label: 'Wood', stroke: '#8a5a30', highlight: '#c58b4a', mortar: '#4c2d17' },
  { value: 'plaster', label: 'Plaster', stroke: '#c9c1ad', highlight: '#f0ead8', mortar: '#a49a84' },
]
const OPENING_PLACE_RADIUS = 34
const OBJECT_CULL_PADDING = 220
const DEFAULT_LOCATION_FILL = '#c8602a'
const DEFAULT_LOCATION_STROKE = '#6a2a0a'
const DEFAULT_LOCATION_ICON_SIZE = 64
const DEFAULT_LOCATION_LABEL_SIZE = 13
const DEFAULT_LOCATION_LABEL_COLOR = '#1a140a'
const DEFAULT_LOCATION_LABEL_OUTLINE = '#f4e8c4'
const DEFAULT_REGION_FILL_OPACITY = 0.16
const objectRenderBoundsCache = new WeakMap()

function sortVisibleObjects(objects) {
  return [...objects].filter(o => o.visible !== false).sort((a, b) => (a.zIndex || 0) - (b.zIndex || 0))
}

function boundsIntersect(a, b, padding = 0) {
  return a.x <= b.x + b.width + padding &&
    a.x + a.width >= b.x - padding &&
    a.y <= b.y + b.height + padding &&
    a.y + a.height >= b.y - padding
}

function projectPointToSegment(point, a, b) {
  const dx = b.x - a.x
  const dy = b.y - a.y
  const len2 = dx * dx + dy * dy
  if (!len2) return { point: a, t: 0, distance: Math.hypot(point.x - a.x, point.y - a.y), segmentLength: 0 }
  const t = clamp(((point.x - a.x) * dx + (point.y - a.y) * dy) / len2, 0, 1)
  const projected = { x: a.x + dx * t, y: a.y + dy * t }
  return { point: projected, t, distance: Math.hypot(point.x - projected.x, point.y - projected.y), segmentLength: Math.sqrt(len2), dx, dy }
}

function getLocalWallMaterial(value) {
  return LOCAL_WALL_MATERIALS.find(m => m.value === value) || LOCAL_WALL_MATERIALS[0]
}

function getObjectRenderBounds(object) {
  const cached = objectRenderBoundsCache.get(object)
  if (cached) return cached
  const b = getObjectBounds(object)
  const pointSize = Math.max(object.height || 0, object.width || 0, Number(object.properties?.iconSize) || 0, 80)
  const pad = object.geometry?.type
    ? Math.max(48, Number(object.properties?.lineThickness || 0) * 4)
    : Math.max(48, pointSize * 0.5)
  let bounds = { x: b.x - pad, y: b.y - pad, width: b.width + pad * 2, height: b.height + pad * 2 }

  // Territory labels can be moved well outside their polygon. Include that
  // offset label in culling bounds so it does not disappear while panning.
  const name = object.properties?.name || ''
  if (object.type === 'territory' && name && !object.properties?.labelHidden) {
    const fontSize = Number(object.properties?.labelFontSize) || 22
    const labelX = b.x + b.width / 2 + (object.properties?.labelOffsetX || 0)
    const labelY = b.y + b.height / 2 + (object.properties?.labelOffsetY || 0)
    const labelWidth = Math.max(fontSize * 2, name.length * fontSize * 0.65)
    const left = Math.min(bounds.x, labelX - labelWidth / 2 - 12)
    const top = Math.min(bounds.y, labelY - fontSize - 12)
    const right = Math.max(bounds.x + bounds.width, labelX + labelWidth / 2 + 12)
    const bottom = Math.max(bounds.y + bounds.height, labelY + fontSize + 12)
    bounds = { x: left, y: top, width: right - left, height: bottom - top }
  }

  objectRenderBoundsCache.set(object, bounds)
  return bounds
}

function StampPreviewCanvas({ stamp, stylePreset, active }) {
  const canvasRef = useRef(null)

  useEffect(() => {
    function render() {
      const canvas = canvasRef.current
      if (!canvas || !stamp) return
      const size = 58
      const dpr = window.devicePixelRatio || 1
      canvas.width = size * dpr
      canvas.height = size * dpr
      canvas.style.width = `${size}px`
      canvas.style.height = `${size}px`
      const ctx = canvas.getContext('2d')
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
      ctx.clearRect(0, 0, size, size)
      const stampSize = Math.min(48, Math.max(34, (stamp.size || 80) * 0.4))
      drawObject(ctx, {
        id: `stamp-preview-${stamp.id}`,
        type: 'stamp',
        x: size / 2,
        y: size / 2,
        width: stampSize,
        height: stampSize,
        zIndex: 0,
        properties: { stampId: stamp.id, name: stamp.name, showLabel: false },
      }, false, { style: stylePreset, preview: false })
    }

    render()
    window.addEventListener('yow:stamp-asset-loaded', render)
    return () => window.removeEventListener('yow:stamp-asset-loaded', render)
  }, [stamp, stylePreset])

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      style={{
        display: 'block',
        width: 58,
        height: 58,
        borderRadius: 8,
        background: 'color-mix(in srgb, var(--surface) 82%, #fff 18%)',
        boxShadow: 'inset 0 0 0 1px color-mix(in srgb, var(--border) 65%, transparent)',
        filter: active ? 'drop-shadow(0 0 5px color-mix(in srgb, var(--accent) 45%, transparent))' : 'none',
      }}
    />
  )
}

// ─── Main component ───────────────────────────────────────────────────────────

export default function MapBuilder({ store }) {
  const { mapProject: project, addMap, selectMap, deleteMap, renameMap, updateActiveMapData, saveLocation, setSelectedLocationId } = store

  if (!project) {
    return (
      <div style={{ flex: 1, display: 'grid', placeItems: 'center', background: 'var(--bg)' }}>
        <div style={{ color: 'var(--muted)', fontSize: 14 }}>Open a project to use the map builder.</div>
      </div>
    )
  }

  const activeMap = (project.maps || []).find(m => m.id === project.activeMapId) || null
  if (!activeMap) {
    return (
      <MapDashboard
        project={project}
        addMap={addMap}
        selectMap={selectMap}
        deleteMap={deleteMap}
        renameMap={renameMap}
      />
    )
  }

  return (
    <MapEditor
      key={activeMap.id}
      activeMap={activeMap}
      project={project}
      addMap={addMap}
      selectMap={selectMap}
      deleteMap={deleteMap}
      renameMap={renameMap}
      updateActiveMapData={updateActiveMapData}
      saveLocation={saveLocation}
      setSelectedLocationId={setSelectedLocationId}
    />
  )
}

// ─── Map Dashboard ────────────────────────────────────────────────────────────

function MapDashboard({ project, addMap, selectMap, deleteMap, renameMap }) {
  const [showModal, setShowModal] = useState(false)
  const [renamingId, setRenamingId] = useState(null)
  const [renameVal, setRenameVal] = useState('')
  const maps = project.maps || []

  function handleCreate({ name, mapType, stylePreset }) {
    const id = addMap(name, mapType, { stylePreset })
    if (id) {
      setTimeout(() => selectMap(id), 0)
    }
    setShowModal(false)
  }

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', background: 'var(--bg)', padding: '32px 40px', gap: 24, overflowY: 'auto' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <h2 style={{ margin: 0, fontSize: 20, fontWeight: 700, color: 'var(--text)' }}>Maps</h2>
        <button className="btn btn-primary btn-sm" onClick={() => setShowModal(true)}>New map</button>
      </div>

      {!maps.length ? (
        <div style={{ flex: 1, display: 'grid', placeItems: 'center' }}>
          <div style={{ textAlign: 'center', display: 'flex', flexDirection: 'column', gap: 12, alignItems: 'center' }}>
            <div style={{ fontSize: 40 }}>🗺️</div>
            <div style={{ color: 'var(--text)', fontWeight: 600 }}>Create your first map</div>
            <div style={{ color: 'var(--muted)', fontSize: 13 }}>Start shaping your world with landmasses, terrain, cities, and routes.</div>
            <button className="btn btn-primary btn-sm" onClick={() => setShowModal(true)}>Create map</button>
          </div>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 16 }}>
          {maps.map(map => (
            <div
              key={map.id}
              style={{ border: '1px solid var(--border)', borderRadius: 10, overflow: 'hidden', background: 'var(--surface)', display: 'flex', flexDirection: 'column' }}
            >
              <button
                type="button"
                aria-label={`Open ${map.name || 'untitled map'}`}
                style={{ width: '100%', height: 120, padding: 0, border: 'none', background: map.metadata?.stylePreset === 'blueprint' ? '#1a2b4a' : map.metadata?.stylePreset === 'atlas' ? '#c0d8e4' : '#e8d6a4', cursor: 'pointer', display: 'grid', placeItems: 'center', fontSize: 32 }}
                onClick={() => selectMap(map.id)}
              >
                🗺️
              </button>
              <div style={{ padding: '10px 12px', display: 'flex', flexDirection: 'column', gap: 6, flex: 1 }}>
                {renamingId === map.id ? (
                  <input
                    autoFocus
                    value={renameVal}
                    onChange={e => setRenameVal(e.target.value)}
                    onBlur={() => { if (renameVal.trim()) renameMap(map.id, renameVal.trim()); setRenamingId(null) }}
                    onKeyDown={e => { if (e.key === 'Enter') { if (renameVal.trim()) renameMap(map.id, renameVal.trim()); setRenamingId(null) } if (e.key === 'Escape') setRenamingId(null) }}
                    style={{ border: '1px solid var(--accent)', borderRadius: 5, padding: '4px 7px', background: 'var(--surface2)', color: 'var(--text)', fontFamily: 'inherit', fontSize: 16, fontWeight: 600, width: '100%' }}
                  />
                ) : (
                  <div style={{ fontWeight: 600, fontSize: 14, color: 'var(--text)', cursor: 'pointer' }} onDoubleClick={() => { setRenamingId(map.id); setRenameVal(map.name || '') }}>
                    {map.name || 'Untitled Map'}
                  </div>
                )}
                <div style={{ fontSize: 11, color: 'var(--muted)', textTransform: 'capitalize' }}>
                  {(map.mapType || 'region').replace('_', ' ')} · {(map.mapObjects || []).length} objects
                </div>
                <div style={{ display: 'flex', gap: 6, marginTop: 4 }}>
                  <button className="btn btn-primary btn-sm" style={{ flex: 1, fontSize: 12 }} onClick={() => selectMap(map.id)}>Open</button>
                  <button className="btn btn-secondary btn-sm" style={{ fontSize: 12 }} onClick={() => { setRenamingId(map.id); setRenameVal(map.name || '') }}>Rename</button>
                  {maps.length > 1 && <button className="btn btn-secondary btn-sm" style={{ fontSize: 12 }} onClick={() => { if (confirm('Delete this map?')) deleteMap(map.id) }}>Delete</button>}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {showModal && <NewMapModal onClose={() => setShowModal(false)} onCreate={handleCreate} />}
    </div>
  )
}

function NewMapModal({ onClose, onCreate }) {
  const [newMapName, setNewMapName] = useState('')
  const [newMapType, setNewMapType] = useState('region')
  const [newMapStyle, setNewMapStyle] = useState('parchment')

  function handleSubmit(e) {
    e.preventDefault()
    onCreate({
      name: newMapName.trim() || 'Untitled Map',
      mapType: newMapType,
      stylePreset: newMapStyle,
    })
  }

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.72)', display: 'grid', placeItems: 'center', zIndex: 999 }} onClick={e => { if (e.target === e.currentTarget) onClose() }}>
      <form onSubmit={handleSubmit} style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 12, padding: '24px 24px 22px', width: 'min(520px, calc(100vw - 32px))', display: 'flex', flexDirection: 'column', gap: 18, boxShadow: '0 24px 64px rgba(0,0,0,0.5)' }}>
        <div>
          <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--accent)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 6 }}>New map</div>
          <h2 style={{ margin: 0, fontSize: 22, fontWeight: 700, color: 'var(--text)' }}>Create a map</h2>
        </div>

        <Field label="Map name">
          <input autoFocus value={newMapName} onChange={e => setNewMapName(e.target.value)} placeholder="Untitled Map" style={{ ...inputStyle, fontSize: 16, padding: '10px 12px' }} />
        </Field>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          <span style={{ fontSize: 11, color: 'var(--muted)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Map type</span>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: 8 }}>
            {MAP_TYPE_OPTIONS.map(t => {
              const isActive = newMapType === t.value
              return (
                <button
                  key={t.value}
                  type="button"
                  onClick={() => setNewMapType(t.value)}
                  aria-pressed={isActive}
                  style={{
                    minHeight: 86,
                    padding: '12px 14px',
                    borderRadius: 8,
                    textAlign: 'left',
                    cursor: 'pointer',
                    fontFamily: 'inherit',
                    border: `2px solid ${isActive ? 'var(--accent)' : 'var(--border)'}`,
                    background: isActive ? 'color-mix(in srgb, var(--accent) 12%, var(--surface2))' : 'var(--surface2)',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 5 }}>
                    <span style={{ width: 24, height: 24, display: 'grid', placeItems: 'center', borderRadius: 6, background: isActive ? 'var(--accent)' : 'color-mix(in srgb, var(--text) 8%, transparent)', color: isActive ? '#fff' : 'var(--muted)', fontWeight: 800 }}>{MAP_TYPE_ICON[t.value] || '□'}</span>
                    <div style={{ fontWeight: 700, fontSize: 13, color: isActive ? 'var(--accent)' : 'var(--text)' }}>{t.label}</div>
                  </div>
                  <div style={{ fontSize: 11, color: 'var(--muted)', lineHeight: 1.35 }}>{MAP_TYPE_HELP[t.value] || 'Planning map'}</div>
                </button>
              )
            })}
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          <span style={{ fontSize: 11, color: 'var(--muted)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Visual style</span>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, minmax(0, 1fr))', gap: 6 }}>
            {STYLE_PRESETS.map(s => {
              const isActive = newMapStyle === s.value
              return (
                <button
                  key={s.value}
                  type="button"
                  onClick={() => setNewMapStyle(s.value)}
                  aria-pressed={isActive}
                  style={{
                    padding: '8px 6px',
                    borderRadius: 8,
                    cursor: 'pointer',
                    fontFamily: 'inherit',
                    border: `2px solid ${isActive ? 'var(--accent)' : 'var(--border)'}`,
                    background: isActive ? 'color-mix(in srgb, var(--accent) 12%, var(--surface2))' : 'var(--surface2)',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    gap: 5,
                    minWidth: 0,
                  }}
                >
                  <div style={{ width: '100%', height: 28, borderRadius: 5, background: STYLE_SWATCHES[s.value] || '#d8d0bc', border: '1px solid rgba(0,0,0,0.18)' }} />
                  <span style={{ fontSize: 10, fontWeight: isActive ? 700 : 500, color: isActive ? 'var(--accent)' : 'var(--muted)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: '100%' }}>{s.label}</span>
                </button>
              )
            })}
          </div>
        </div>

        <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', borderTop: '1px solid var(--border)', paddingTop: 16 }}>
          <button className="btn btn-secondary btn-sm" type="button" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary btn-sm" type="submit" style={{ minWidth: 100 }}>Create map</button>
        </div>
      </form>
    </div>
  )
}

// ─── Map Editor ───────────────────────────────────────────────────────────────

function MapEditor({ activeMap, project, addMap, selectMap, deleteMap, renameMap, updateActiveMapData, saveLocation, setSelectedLocationId }) {
  const canvasRef = useRef(null)
  const viewportRef = useRef(null)
  const frameRef = useRef(null)
  const interactionRef = useRef(null)
  const viewRef = useRef({ zoom: DEFAULT_ZOOM, pan: { x: 80, y: 80 } })
  const objectsRef = useRef([])
  const objectByIdRef = useRef(new Map())
  const visibleObjectsRef = useRef([])
  const selectedIdsRef = useRef([])
  const hoveredIdRef = useRef(null)
  const cursorMapPointRef = useRef(null)
  const draftRef = useRef(null)
  const schemaRef = useRef({ objects: [], layers: [], metadata: {} })
  const baseCanvasRef = useRef({ key: '', canvas: null })
  const undoStackRef = useRef([])
  const redoStackRef = useRef([])
  const spacePressedRef = useRef(false)

  const [editorMode, setEditorMode] = useState('create') // 'create' | 'view'
  const [viewTooltip, setViewTooltip] = useState(null) // { x, y, object }
  const [mode, setModeState] = useState('select')
  const [view, setView] = useState(viewRef.current)
  const [selectedIds, setSelectedIds] = useState([])
  const [hoveredId, setHoveredId] = useState(null)
  const [hoveredPointHandle, setHoveredPointHandle] = useState(null)
  const [hoveredResizeHandle, setHoveredResizeHandle] = useState(null)
  const [draft, setDraft] = useState(null)
  const [historyVersion, setHistoryVersion] = useState(0)
  const [stampSearch, setStampSearch] = useState('')
  const [stampCategory, setStampCategory] = useState('All')
  const [polygonDrawMode, setPolygonDrawMode] = useState('point')
  const [geometryEditMode, setGeometryEditMode] = useState('points')
  const [selectedTerrainType, setSelectedTerrainType] = useState('forest')
  const [selectedStampId, setSelectedStampId] = useState('capital')
  const [selectedOpeningKind, setSelectedOpeningKind] = useState('door')
  const [selectedDoorSwing, setSelectedDoorSwing] = useState('left-a')
  const [roomLineStyle, setRoomLineStyle] = useState('straight')
  const [wallLineStyle, setWallLineStyle] = useState('straight')
  const [localWallMaterial, setLocalWallMaterial] = useState('grey-brick')
  const [localWallThickness, setLocalWallThickness] = useState(16)
  const [localPathThickness, setLocalPathThickness] = useState(14)
  const [favoriteStamps, setFavoriteStamps] = useState(() => loadJson('yow_map_fav_stamps', []))
  const [recentStamps, setRecentStamps] = useState(() => loadJson('yow_map_recent_stamps', []))
  const [modal, setModal] = useState(null) // { kind, point?, ... }
  const [showNewMapModal, setShowNewMapModal] = useState(false)
  // Per-segment selection on line objects: { objectId, index } where index is
  // the segment between geometry points[index] and points[index + 1].
  const [selectedSegment, setSelectedSegment] = useState(null)
  const selectedSegmentRef = useRef(null)
  function setMode(nextMode) {
    setModeState(nextMode)
    if (nextMode !== 'select' && selectedSegmentRef.current) setSelectedSegment(null)
  }
  // MapEditor remounts whenever the active map changes (key={activeMap.id}),
  // so the selected inspector tab is kept outside component state to survive
  // map switches and deletions.
  const [inspectorTab, setInspectorTabState] = useState(() => loadJson('yow_map_inspector_tab', 'object'))
  const setInspectorTab = (tab) => { setInspectorTabState(tab); saveJson('yow_map_inspector_tab', tab) }

  // Label tool config
  const [labelConfig, setLabelConfig] = useState({ text: '', fontSize: 40, fontFamily: MAP_FONT_OPTIONS[0].value, fontWeight: 600, fontStyle: 'normal', textColor: '#1a140a', outlineColor: '#f4e8c4', backgroundColor: 'transparent' })
  // Location tool config
  const [locConfig, setLocConfig] = useState({
    name: '',
    markerIcon: 'pin',
    size: 64,
    iconSize: DEFAULT_LOCATION_ICON_SIZE,
    fill: DEFAULT_LOCATION_FILL,
    stroke: DEFAULT_LOCATION_STROKE,
    labelFontSize: 18,
    labelColor: DEFAULT_LOCATION_LABEL_COLOR,
    labelOutlineColor: DEFAULT_LOCATION_LABEL_OUTLINE,
    linkToId: '',
    createNew: false,
  })
  // Note tool config
  const [noteConfig, setNoteConfig] = useState({ title: '', body: '', gmOnly: false, visibility: 'private' })
  const [territoryConfig, setTerritoryConfig] = useState({ name: '', fill: '#7050a8', linkToId: '', createNewLocation: false })

  // Parse the stored map
  const schema = useMemo(() => parseMapSchema(activeMap), [activeMap])
  const objects = schema.objects
  const stylePreset = schema.metadata?.stylePreset || 'parchment'
  const gridSettings = useMemo(() => normalizeGrid(schema.metadata?.gridSettings, activeMap?.mapType), [schema.metadata?.gridSettings, activeMap?.mapType])
  const activeMapType = activeMap?.mapType || 'region'
  const isInteriorMap = activeMapType === 'interior'
  const isLocalMap = activeMapType === 'local'
  const isWorldMap = activeMapType === 'world'
  const isCampaign = ['dnd_campaign', 'tabletop_rpg'].includes(project?.type)
  const territoryNoun = territoryNounFor(activeMapType)
  const territoryNounPlural = territoryNounPluralFor(activeMapType)
  // Existing maps saved before the base-layer setting keep the water default.
  const baseLayer = schema.metadata?.baseLayer || 'water'

  const visibleObjects = useMemo(() => sortVisibleObjects(objects), [objects])

  const objectsById = useMemo(() => new Map(objects.map(object => [object.id, object])), [objects])
  const selectedObjects = selectedIds.map(id => objectsById.get(id)).filter(Boolean)
  const primarySelection = selectedObjects[0] || null

  const allowedTools = MAP_TYPE_TOOLS[activeMapType] || MAP_TYPE_TOOLS.region
  const activeTools = TOOLS
    .filter(t => allowedTools.includes(t.id))
    .map(t => {
      if (isInteriorMap && t.id === 'region') return { ...t, label: 'Room', icon: '▣' }
      if (isLocalMap && t.id === 'region') return { ...t, label: 'Area', icon: '▱' }
      if (isWorldMap && t.id === 'region') return { ...t, label: 'Kingdom', icon: '♔' }
      if (t.id === 'region') return { ...t, label: 'Territory', icon: '▢' }
      return t
    })

  const allStampCategories = useMemo(() => {
    const source = isInteriorMap
      ? STAMP_LIBRARY.filter(s => INTERIOR_STAMP_CATEGORIES.has(s.category))
      : isLocalMap
        ? STAMP_LIBRARY.filter(s => LOCAL_STAMP_CATEGORIES.has(s.category))
        : STAMP_LIBRARY
    const cats = new Set(source.map(s => s.category))
    return ['All', 'Favourites', 'Recent', ...cats]
  }, [isInteriorMap, isLocalMap])

  const filteredStamps = useMemo(() => {
    const q = stampSearch.trim().toLowerCase()
    return STAMP_LIBRARY.filter(s => {
      if (isInteriorMap && !INTERIOR_STAMP_CATEGORIES.has(s.category)) return false
      if (isLocalMap && !LOCAL_STAMP_CATEGORIES.has(s.category)) return false
      if (stampCategory === 'Favourites') return favoriteStamps.includes(s.id)
      if (stampCategory === 'Recent') return recentStamps.includes(s.id)
      if (stampCategory !== 'All' && s.category !== stampCategory) return false
      if (q) return `${s.name} ${s.category} ${s.keywords || ''}`.toLowerCase().includes(q)
      return true
    })
  }, [stampSearch, stampCategory, favoriteStamps, recentStamps, isInteriorMap, isLocalMap])

  const effectiveSelectedStampId = filteredStamps.some(s => s.id === selectedStampId)
    ? selectedStampId
    : (filteredStamps[0]?.id || selectedStampId)

  // Sync refs
  useEffect(() => {
    objectsRef.current = objects
    objectByIdRef.current = objectsById
    visibleObjectsRef.current = visibleObjects
    selectedIdsRef.current = selectedIds
  }, [objects, objectsById, selectedIds, visibleObjects])
  // Layers/metadata must be read through a ref inside persistence paths: the
  // window keydown handler mounts once, so a closed-over `schema` goes stale
  // and keyboard delete/undo/redo would write back old metadata (dropping
  // e.g. baseLayer) and old layers.
  useEffect(() => { schemaRef.current = schema }, [schema])
  useEffect(() => { selectedSegmentRef.current = selectedSegment; requestRender() }, [selectedSegment]) // eslint-disable-line react-hooks/exhaustive-deps
  // Segment selection only survives while its object stays the selection.
  useEffect(() => {
    if (selectedSegmentRef.current && !selectedIds.includes(selectedSegmentRef.current.objectId)) setSelectedSegment(null)
  }, [selectedIds])
  useEffect(() => { hoveredIdRef.current = hoveredId; requestRender() }, [hoveredId]) // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { draftRef.current = draft; requestRender() }, [draft]) // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { viewRef.current = view; requestRender() }, [view]) // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { undoStackRef.current = []; redoStackRef.current = [] }, [activeMap?.id])
  useEffect(() => {
    if (!['stamp', 'location', 'label', 'note'].includes(mode)) {
      cursorMapPointRef.current = null
      requestRender()
    }
  }, [mode]) // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    requestRender()
  }, [visibleObjects, selectedIds, mode, selectedStampId, labelConfig, locConfig, noteConfig]) // eslint-disable-line react-hooks/exhaustive-deps

  // Keyboard shortcuts
  useEffect(() => {
    const onKeyDown = e => {
      const typing = e.target && ['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName)
      if (typing) return
      if (e.code === 'Space') { spacePressedRef.current = true; return }
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'z') { e.preventDefault(); e.shiftKey ? redo() : undo(); return }
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'y') { e.preventDefault(); redo(); return }
      if ((e.key === 'Delete' || e.key === 'Backspace') && (selectedSegmentRef.current || selectedIdsRef.current.length)) { e.preventDefault(); deleteSelected(); return }
      if (e.key === 'Escape' && selectedSegmentRef.current) { e.preventDefault(); setSelectedSegment(null); return }
      if (e.key === 'Escape' && draftRef.current) { e.preventDefault(); setDraft(null); return }
      if (e.key === 'Enter' && draftRef.current?.points?.length >= 2) { e.preventDefault(); completeDraft(); return }
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'a') { e.preventDefault(); setSelectedIds(objectsRef.current.filter(o => !o.locked).map(o => o.id)); return }
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'd' && selectedIdsRef.current.length) { e.preventDefault(); duplicateSelected(); return }
      if (e.key === 'v' || e.key === 'V') { setMode('select'); setDraft(null) }
    }
    const onKeyUp = e => { if (e.code === 'Space') spacePressedRef.current = false }
    window.addEventListener('keydown', onKeyDown)
    window.addEventListener('keyup', onKeyUp)
    return () => { window.removeEventListener('keydown', onKeyDown); window.removeEventListener('keyup', onKeyUp) }
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  // Stamp asset event
  useEffect(() => {
    const onLoad = () => requestRender()
    window.addEventListener('yow:stamp-asset-loaded', onLoad)
    return () => window.removeEventListener('yow:stamp-asset-loaded', onLoad)
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  // Fit on mount
  useEffect(() => { fitCanvas() }, [])

  // ── Persistence ────────────────────────────────────────────────────────────

  function persistMap({ mapObjects = objectsRef.current, mapLayers = schemaRef.current.layers, metadata = schemaRef.current.metadata } = {}) {
    updateActiveMapData(() => ({
      schemaVersion: SCHEMA_VERSION,
      width: MAP_W, height: MAP_H,
      mapObjects,
      mapLayers,
      metadata,
    }))
  }

  function persistObjects(nextObjects) {
    persistMap({ mapObjects: nextObjects })
  }

  function persistLayers(nextLayers) {
    takeSnapshot()
    persistMap({ mapLayers: nextLayers })
  }

  function persistMeta(patch) {
    takeSnapshot()
    persistMap({ metadata: { ...(schemaRef.current.metadata || {}), ...patch } })
  }

  // ── History ────────────────────────────────────────────────────────────────

  function takeSnapshot() {
    undoStackRef.current = [...undoStackRef.current.slice(-39), {
      mapObjects: objectsRef.current.map(o => ({ ...o })),
      mapLayers: schemaRef.current.layers,
      metadata: schemaRef.current.metadata,
    }]
    redoStackRef.current = []
    setHistoryVersion(v => v + 1)
  }

  function applySnapshot(snap) {
    updateActiveMapData(() => ({ schemaVersion: SCHEMA_VERSION, width: MAP_W, height: MAP_H, ...snap }))
    setSelectedIds([]); setDraft(null)
  }

  function undo() {
    const prev = undoStackRef.current.pop()
    if (!prev) return
    redoStackRef.current = [...redoStackRef.current.slice(-39), { mapObjects: objectsRef.current, mapLayers: schemaRef.current.layers, metadata: schemaRef.current.metadata }]
    applySnapshot(prev); setHistoryVersion(v => v + 1)
  }

  function redo() {
    const next = redoStackRef.current.pop()
    if (!next) return
    undoStackRef.current = [...undoStackRef.current.slice(-39), { mapObjects: objectsRef.current, mapLayers: schemaRef.current.layers, metadata: schemaRef.current.metadata }]
    applySnapshot(next); setHistoryVersion(v => v + 1)
  }

  // ── Object mutations ────────────────────────────────────────────────────────

  function updateObjects(updater, { nextLayers } = {}) {
    takeSnapshot()
    const next = typeof updater === 'function' ? updater(objectsRef.current) : updater
    persistMap({
      mapObjects: next,
      mapLayers: nextLayers === undefined ? schemaRef.current.layers : nextLayers,
    })
  }

  function updateObjectsTransient(updater) {
    const next = typeof updater === 'function' ? updater(objectsRef.current) : updater
    objectsRef.current = next
    objectByIdRef.current = new Map(next.map(object => [object.id, object]))
    // Transient interactions only move/resize existing objects, so z-order and
    // visibility are unchanged. Preserve the existing order instead of sorting
    // the whole map on every pointermove.
    visibleObjectsRef.current = visibleObjectsRef.current
      .map(object => objectByIdRef.current.get(object.id))
      .filter(Boolean)
    requestRender()
  }

  function patchSelected(patch) {
    const ids = new Set(selectedIds)
    updateObjects(cur => cur.map(o => ids.has(o.id) && !o.locked
      ? { ...o, ...patch, properties: patch.properties ? { ...o.properties, ...patch.properties } : o.properties, linkedEntity: patch.linkedEntity !== undefined ? patch.linkedEntity : o.linkedEntity }
      : o))
  }

  function deleteSelected() {
    // A selected segment takes priority: Delete removes just that segment
    // rather than the whole object.
    if (deleteSelectedSegment()) return
    const ids = new Set(selectedIdsRef.current)
    updateObjects(cur => cur.filter(o => !ids.has(o.id) || o.locked))
    setSelectedIds([])
  }

  // Removes one segment of a line object. End segments drop their endpoint;
  // a middle segment splits the path into two objects of the same type that
  // keep the original layer/group. Returns true when a segment was handled.
  function deleteSelectedSegment() {
    const seg = selectedSegmentRef.current
    if (!seg) return false
    const obj = objectByIdRef.current.get(seg.objectId)
    const pts = obj?.geometry?.points
    setSelectedSegment(null)
    if (!obj || obj.locked || !pts || pts.length < 2 || seg.index >= pts.length - 1) return false
    if (pts.length === 2) {
      updateObjects(cur => cur.filter(o => o.id !== obj.id))
      setSelectedIds([])
    } else if (seg.index === 0) {
      updateObjects(cur => cur.map(o => o.id === obj.id ? { ...o, geometry: { ...o.geometry, points: pts.slice(1).map(p => ({ ...p })) } } : o))
    } else if (seg.index === pts.length - 2) {
      updateObjects(cur => cur.map(o => o.id === obj.id ? { ...o, geometry: { ...o.geometry, points: pts.slice(0, -1).map(p => ({ ...p })) } } : o))
    } else {
      const second = {
        ...obj,
        id: uid(obj.type),
        properties: { ...obj.properties },
        geometry: { ...obj.geometry, points: pts.slice(seg.index + 1).map(p => ({ ...p })) },
      }
      updateObjects(cur => cur.flatMap(o => o.id === obj.id
        ? [{ ...o, geometry: { ...o.geometry, points: pts.slice(0, seg.index + 1).map(p => ({ ...p })) } }, second]
        : [o]))
      setSelectedIds([obj.id])
    }
    return true
  }

  function duplicateSelected() {
    const ids = new Set(selectedIds)
    const maxZ = Math.max(0, ...objectsRef.current.map(o => o.zIndex || 0))
    const copies = objectsRef.current.filter(o => ids.has(o.id) && !o.locked).map((o, i) => ({
      ...o, id: uid(o.type), x: (o.x || 0) + 36, y: (o.y || 0) + 36, zIndex: maxZ + i + 1,
      geometry: o.geometry ? { ...o.geometry, points: o.geometry.points?.map(p => ({ ...p })) } : null,
    }))
    if (!copies.length) return
    updateObjects(cur => [...cur, ...copies])
    setSelectedIds(copies.map(o => o.id))
  }

  // ── Canvas rendering ────────────────────────────────────────────────────────

  function requestRender() {
    if (frameRef.current) return
    frameRef.current = requestAnimationFrame(() => { frameRef.current = null; renderCanvas() })
  }

  function getBaseCanvas() {
    const key = JSON.stringify({ stylePreset, gridSettings, baseLayer })
    if (baseCanvasRef.current.key === key && baseCanvasRef.current.canvas) return baseCanvasRef.current.canvas
    const base = document.createElement('canvas')
    base.width = MAP_W
    base.height = MAP_H
    const baseCtx = base.getContext('2d')
    drawBackground(baseCtx, MAP_W, MAP_H, stylePreset, baseLayer)
    baseCtx.save()
    baseCtx.beginPath()
    baseCtx.rect(0, 0, MAP_W, MAP_H)
    baseCtx.clip()
    drawMovementGrid(baseCtx, MAP_W, MAP_H, gridSettings)
    baseCtx.restore()
    baseCanvasRef.current = { key, canvas: base }
    return base
  }

  function getViewportMapBounds(rect) {
    const cur = viewRef.current
    return {
      x: (0 - cur.pan.x) / cur.zoom,
      y: (0 - cur.pan.y) / cur.zoom,
      width: rect.width / cur.zoom,
      height: rect.height / cur.zoom,
    }
  }

  function getDrawableObjects(mapBounds, selected) {
    const hovered = hoveredIdRef.current
    return visibleObjectsRef.current.filter(o => (
      selected.has(o.id) ||
      o.id === hovered ||
      boundsIntersect(getObjectRenderBounds(o), mapBounds, OBJECT_CULL_PADDING)
    ))
  }

  function drawObjectsInLayerOrder(ctx, orderedObjects, selectedIds, opts) {
    const selected = selectedIds instanceof Set ? selectedIds : new Set(selectedIds)
    let riverRun = []
    const openings = []
    const flushRivers = () => {
      if (!riverRun.length) return
      drawRiverGroup(ctx, riverRun, selected, opts)
      riverRun = []
    }

    orderedObjects.forEach(object => {
      if (object.type === 'river') {
        riverRun.push(object)
        return
      }
      if (object.type === 'opening') {
        openings.push(object)
        return
      }
      flushRivers()
      drawObject(ctx, object, selected.has(object.id), opts)
    })
    flushRivers()
    openings.forEach(object => drawObject(ctx, object, selected.has(object.id), opts))
  }

  function renderCanvas() {
    const canvas = canvasRef.current
    const vp = viewportRef.current
    if (!canvas || !vp) return
    const rect = vp.getBoundingClientRect()
    const dpr = window.devicePixelRatio || 1
    const w = Math.max(1, Math.floor(rect.width * dpr))
    const h = Math.max(1, Math.floor(rect.height * dpr))
    if (canvas.width !== w || canvas.height !== h) {
      canvas.width = w; canvas.height = h
      canvas.style.width = `${rect.width}px`; canvas.style.height = `${rect.height}px`
    }
    const ctx = canvas.getContext('2d')
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    ctx.clearRect(0, 0, rect.width, rect.height)
    ctx.fillStyle = '#2d3136'
    ctx.fillRect(0, 0, rect.width, rect.height)

    ctx.save()
    ctx.translate(viewRef.current.pan.x, viewRef.current.pan.y)
    ctx.scale(viewRef.current.zoom, viewRef.current.zoom)

    ctx.shadowColor = 'rgba(0,0,0,.28)'
    ctx.shadowBlur = 40 / viewRef.current.zoom
    ctx.shadowOffsetY = 12 / viewRef.current.zoom
    ctx.drawImage(getBaseCanvas(), 0, 0)
    ctx.shadowColor = 'transparent'

    ctx.save()
    ctx.beginPath(); ctx.rect(0, 0, MAP_W, MAP_H); ctx.clip()
    const selected = new Set(selectedIdsRef.current)
    const drawableObjects = getDrawableObjects(getViewportMapBounds(rect), selected)
    drawObjectsInLayerOrder(ctx, drawableObjects, selected, { style: stylePreset, mapType: activeMapType, zoom: viewRef.current.zoom, geometryEditMode })

    // Selected line segment highlight (double-click selection)
    const seg = selectedSegmentRef.current
    if (seg) {
      const segObj = objectByIdRef.current.get(seg.objectId)
      const segPts = segObj?.geometry?.points
      if (segObj && segPts && seg.index < segPts.length - 1) {
        const a = segPts[seg.index], b = segPts[seg.index + 1]
        const zoom = viewRef.current.zoom || 1
        ctx.save()
        ctx.lineCap = 'round'
        ctx.strokeStyle = '#ffb020'
        ctx.globalAlpha = 0.85
        ctx.lineWidth = (Number(segObj.properties?.lineThickness) || 6) + 6 / zoom
        ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke()
        ctx.globalAlpha = 1
        ctx.fillStyle = '#ffb020'
        ctx.strokeStyle = '#5a3a00'
        ctx.lineWidth = 2 / zoom
        const r = 6 / zoom
        ;[a, b].forEach(p => { ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, Math.PI * 2); ctx.fill(); ctx.stroke() })
        ctx.restore()
      }
    }
    ctx.restore()

    // cursor preview
    const cursorMapPoint = cursorMapPointRef.current
    if (cursorMapPoint && !modal && ['stamp', 'location', 'opening'].includes(mode)) {
      const previewOpts = { style: stylePreset, mapType: activeMapType, preview: true }
      if (mode === 'stamp') {
        const stamp = STAMP_LIBRARY.find(s => s.id === effectiveSelectedStampId)
        const size = stamp?.size || 80
        const prev = { id: 'preview', type: 'stamp', x: cursorMapPoint.x, y: cursorMapPoint.y, width: size, height: size, zIndex: 9999, properties: { stampId: effectiveSelectedStampId, name: stamp?.name || '', showLabel: false } }
        ctx.save(); ctx.globalAlpha = 0.68; drawObject(ctx, prev, false, previewOpts); ctx.restore()
      } else if (mode === 'location') {
        const size = locConfig.size || 64
        const prev = {
          id: 'preview',
          type: 'location',
          x: cursorMapPoint.x,
          y: cursorMapPoint.y,
          width: size,
          height: size,
          zIndex: 9999,
          properties: {
            markerIcon: locConfig.markerIcon,
            iconSize: locConfig.iconSize,
            fill: locConfig.fill,
            stroke: locConfig.stroke,
            labelFontSize: locConfig.labelFontSize,
            labelColor: locConfig.labelColor,
            labelOutlineColor: locConfig.labelOutlineColor,
            name: '',
          },
        }
        ctx.save(); ctx.globalAlpha = 0.68; drawObject(ctx, prev, false, previewOpts); ctx.restore()
      } else if (mode === 'opening') {
        const match = findNearestWallOpening(cursorMapPoint)
        if (match) {
          const prev = {
            id: 'preview',
            type: 'opening',
            x: 0,
            y: 0,
            width: 0,
            height: 0,
            zIndex: 9999,
            geometry: { type: 'path', points: match.points },
            properties: {
              name: selectedOpeningKind === 'window' ? 'Window' : 'Door',
              openingKind: selectedOpeningKind,
              doorSwing: selectedDoorSwing,
              wallId: match.wall.id,
              wallThickness: match.wallThickness,
            },
          }
          drawObject(ctx, prev, false, previewOpts)
        }
      }
    }

    // hover
    const hovObj = selectedIdsRef.current.includes(hoveredIdRef.current)
      ? null
      : objectByIdRef.current.get(hoveredIdRef.current)
    drawHoverHighlight(ctx, hovObj, viewRef.current.zoom)

    // draft
    drawDraft(ctx, draftRef.current, viewRef.current.zoom)
    ctx.restore()
  }

  // ── View helpers ────────────────────────────────────────────────────────────

  function fitCanvas() {
    const vp = viewportRef.current
    if (!vp) return
    const rect = vp.getBoundingClientRect()
    const pad = 80
    const zoom = clamp(Math.min((rect.width - pad) / MAP_W, (rect.height - pad) / MAP_H, 1), MIN_ZOOM, MAX_ZOOM)
    const next = { zoom, pan: { x: (rect.width - MAP_W * zoom) / 2, y: (rect.height - MAP_H * zoom) / 2 } }
    viewRef.current = next; setView(next)
  }

  function zoomAt(clientX, clientY, factor) {
    const vp = viewportRef.current; if (!vp) return
    const rect = vp.getBoundingClientRect()
    const cur = viewRef.current
    const nextZoom = clamp(cur.zoom * factor, MIN_ZOOM, MAX_ZOOM)
    const sx = clientX - rect.left, sy = clientY - rect.top
    const mapX = (sx - cur.pan.x) / cur.zoom, mapY = (sy - cur.pan.y) / cur.zoom
    setView({ zoom: nextZoom, pan: { x: sx - mapX * nextZoom, y: sy - mapY * nextZoom } })
  }

  function zoomCenter(factor) {
    const vp = viewportRef.current; if (!vp) return
    const rect = vp.getBoundingClientRect()
    zoomAt(rect.left + rect.width / 2, rect.top + rect.height / 2, factor)
  }

  // ── Hit test ────────────────────────────────────────────────────────────────

  function hitTest(point) {
    // Non-polygon first (top to bottom z-order)
    const visible = visibleObjectsRef.current
    for (let i = visible.length - 1; i >= 0; i--) {
      const o = visible[i]
      if (!o.geometry?.type && objectContainsPoint(o, point)) return o
    }
    // Then polygons/paths
    for (let i = visible.length - 1; i >= 0; i--) {
      const o = visible[i]
      if (o.geometry?.type && objectContainsPoint(o, point)) return o
    }
    return null
  }

  function getTerritoryLabelPoint(object) {
    if (!object || object.type !== 'territory' || !object.geometry?.points?.length) return null
    const name = object.properties?.name || ''
    if (!name || object.properties?.labelHidden) return null
    const b = getObjectBounds(object)
    return {
      x: b.x + b.width / 2 + (object.properties?.labelOffsetX || 0),
      y: b.y + b.height / 2 + (object.properties?.labelOffsetY || 0),
    }
  }

  function hitTestTerritoryLabelHandle(point) {
    if (mode !== 'select' || selectedIdsRef.current.length !== 1) return null
    const object = objectByIdRef.current.get(selectedIdsRef.current[0])
    if (!object || object.locked) return null
    const labelPoint = getTerritoryLabelPoint(object)
    if (!labelPoint) return null
    const radius = Math.max(8, 12 / viewRef.current.zoom)
    if (Math.hypot(point.x - labelPoint.x, point.y - labelPoint.y) > radius) return null
    return { objectId: object.id, labelPoint }
  }

  function hitTestPointHandle(point) {
    if (mode !== 'select' || geometryEditMode !== 'points' || !selectedIdsRef.current.length) return null
    const selected = new Set(selectedIdsRef.current)
    const radius = Math.max(7, 11 / viewRef.current.zoom)
    const visible = visibleObjectsRef.current
    for (let i = visible.length - 1; i >= 0; i--) {
      const object = visible[i]
      if (!selected.has(object.id) || object.locked) continue
      const points = object.geometry?.points || []
      if (!points.length) continue
      for (let pointIndex = points.length - 1; pointIndex >= 0; pointIndex--) {
        const p = points[pointIndex]
        if (Math.hypot(point.x - p.x, point.y - p.y) <= radius) {
          return { objectId: object.id, pointIndex }
        }
      }
    }
    return null
  }

  function getResizeHandles(object) {
    const b = getObjectBounds(object)
    const pad = Math.max(6, 8 / viewRef.current.zoom)
    return [
      { handle: 'nw', x: b.x - pad, y: b.y - pad, anchorX: b.x + b.width, anchorY: b.y + b.height },
      { handle: 'ne', x: b.x + b.width + pad, y: b.y - pad, anchorX: b.x, anchorY: b.y + b.height },
      { handle: 'se', x: b.x + b.width + pad, y: b.y + b.height + pad, anchorX: b.x, anchorY: b.y },
      { handle: 'sw', x: b.x - pad, y: b.y + b.height + pad, anchorX: b.x + b.width, anchorY: b.y },
    ]
  }

  function hitTestResizeHandle(point) {
    if (mode !== 'select' || selectedIdsRef.current.length !== 1) return null
    const object = objectByIdRef.current.get(selectedIdsRef.current[0])
    if (!object || object.locked) return null
    const canResizeStamp = object.type === 'stamp' && !object.geometry
    const canResizeGeometry = geometryEditMode === 'resize' && object.geometry?.points?.length
    if (!canResizeStamp && !canResizeGeometry) return null
    const radius = Math.max(8, 12 / viewRef.current.zoom)
    return getResizeHandles(object).find(h => Math.hypot(point.x - h.x, point.y - h.y) <= radius) || null
  }

  function resizeGeometryPoints(startPoints, anchor, rawHandlePoint) {
    const handlePoint = getSnappedPoint(rawHandlePoint)
    const startXs = startPoints.map(p => p.x)
    const startYs = startPoints.map(p => p.y)
    const startBounds = {
      minX: Math.min(...startXs),
      maxX: Math.max(...startXs),
      minY: Math.min(...startYs),
      maxY: Math.max(...startYs),
    }
    const startHandleX = anchor.anchorX === startBounds.minX ? startBounds.maxX : startBounds.minX
    const startHandleY = anchor.anchorY === startBounds.minY ? startBounds.maxY : startBounds.minY
    const startW = startHandleX - anchor.anchorX || 1
    const startH = startHandleY - anchor.anchorY || 1
    const nextW = Math.abs(handlePoint.x - anchor.anchorX) < MIN_SIZE
      ? Math.sign(startW) * MIN_SIZE
      : handlePoint.x - anchor.anchorX
    const nextH = Math.abs(handlePoint.y - anchor.anchorY) < MIN_SIZE
      ? Math.sign(startH) * MIN_SIZE
      : handlePoint.y - anchor.anchorY
    const scaleX = nextW / startW
    const scaleY = nextH / startH
    return startPoints.map(p => ({
      x: anchor.anchorX + (p.x - anchor.anchorX) * scaleX,
      y: anchor.anchorY + (p.y - anchor.anchorY) * scaleY,
    }))
  }

  function resizeStampObject(startObject, anchor, rawHandlePoint) {
    const handlePoint = getSnappedPoint(rawHandlePoint)
    const startSize = Math.max(MIN_SIZE, Number(startObject.width) || Number(startObject.height) || 80)
    const deltaX = Math.abs(handlePoint.x - anchor.anchorX)
    const deltaY = Math.abs(handlePoint.y - anchor.anchorY)
    const size = Math.max(MIN_SIZE, Math.max(deltaX, deltaY) || startSize)
    const xSign = anchor.handle.includes('w') ? -1 : 1
    const ySign = anchor.handle.includes('n') ? -1 : 1
    const centerX = anchor.anchorX + (xSign * size) / 2
    const centerY = anchor.anchorY + (ySign * size) / 2
    return { x: centerX, y: centerY, width: size, height: size }
  }

  function getSnappedPoint(point) {
    return gridSettings.snapToGrid ? snapToGrid(point, gridSettings.size || 40, true) : point
  }

  // ── Draft drawing ───────────────────────────────────────────────────────────

  function startOrExtendDraft(rawPoint, tool, shouldClose = false) {
    const point = getSnappedPoint(rawPoint)
    setDraft(cur => {
      const sameTool = cur?.kind === tool
      if (!sameTool) {
        return { kind: tool, points: [point], preview: point, properties: getDefaultProperties(tool) }
      }
      const pts = cur.points
      const first = pts[0]
      const dist = Math.hypot(point.x - first.x, point.y - first.y)
      const canClose = CLOSED_POINT_DRAW_TOOLS.has(tool)
      const minPoints = POLYGON_DRAW_TOOLS.has(tool) ? 3 : 2
      const closesOnOrigin = canClose && pts.length >= 3 && dist <= Math.max(10, 18 / viewRef.current.zoom)
      if (shouldClose || closesOnOrigin) {
        if (pts.length >= minPoints) {
          setTimeout(() => completeDraft({ ...cur, points: pts, closed: closesOnOrigin || POLYGON_DRAW_TOOLS.has(tool) }), 0)
          return null
        }
        return cur
      }
      return { ...cur, points: [...pts, point], preview: point }
    })
  }

  function startFreehandDraft(rawPoint, tool) {
    const point = getSnappedPoint(rawPoint)
    setDraft({ kind: tool, points: [point], preview: point, drawMode: 'freehand', properties: getDefaultProperties(tool) })
    interactionRef.current = { type: 'freehand-draw', tool, lastPoint: point, points: [point] }
  }

  function appendFreehandPoint(rawPoint) {
    const point = getSnappedPoint(rawPoint)
    const minDist = Math.max(7, 12 / viewRef.current.zoom)
    const ia = interactionRef.current
    if (ia?.lastPoint && Math.hypot(point.x - ia.lastPoint.x, point.y - ia.lastPoint.y) < minDist) return
    ia.lastPoint = point
    ia.points = [...(ia.points || []), point]
    setDraft(cur => cur ? { ...cur, points: [...cur.points, point], preview: point } : cur)
  }

  function completeDraft(source) {
    const src = source || draftRef.current
    if (!src?.points?.length) return
    const isPolygon = POLYGON_DRAW_TOOLS.has(src.kind)
    const minPts = isPolygon ? 3 : 2
    if (src.points.length < minPts) { setDraft(null); return }

    // Map tool ID to object type
    const typeMap = { terrain: 'region', region: 'territory', shape: 'shape', wall: 'wall', water: 'water', river: 'river', road: 'road', path: 'path', border: 'border', mountain: 'mountain' }
    const objectType = typeMap[src.kind] || src.kind

    const maxZ = Math.max(0, ...objectsRef.current.map(o => o.zIndex || 0)) + 1
    const obj = normalizeObject({
      id: uid(objectType),
      type: objectType,
      x: 0, y: 0, width: 0, height: 0,
      zIndex: maxZ,
      geometry: {
        type: isPolygon ? 'polygon' : 'path',
        points: src.points,
      },
      properties: {
        ...getDefaultProperties(src.kind),
        ...(objectType === 'territory' && isInteriorMap ? { semanticType: 'room', lineStyle: roomLineStyle, fillOpacity: 0.08, labelColor: '#d7e4ec', labelOutlineColor: 'transparent' } : {}),
        ...(objectType === 'water' && isPolygon ? { waterKind: 'mass', lineThickness: 3 } : {}),
      },
    })
    updateObjects(cur => [...cur, obj])
    setSelectedIds([obj.id])
    setDraft(null)

    // Political regions/rooms need a name — open naming modal
    if (objectType === 'territory') {
      setTerritoryConfig({ name: '', fill: obj.properties.fill || '#7050a8', linkToId: '', createNewLocation: false })
      setModal({ kind: 'territory', objectId: obj.id })
    } else {
      setMode('select')
    }
  }

  function getDefaultProperties(kind) {
    switch (kind) {
      case 'shape': return stylePreset === 'parchment'
        ? { fill: '#f0e3bd', stroke: '#b79a62', organicEdges: true }
        : { fill: '#1e3d20', stroke: '#142a16', organicEdges: true }
      case 'terrain': return { fill: TERRAIN_TYPES.find(t => t.value === selectedTerrainType)?.color || '#6b9e44', stroke: '#2a3a18', terrainFillOpacity: DEFAULT_REGION_FILL_OPACITY, terrainType: selectedTerrainType, terrainSymbolScale: 1 }
      // The UI tool is named "region", but completeDraft stores the political
      // shape as a territory. Keep its defaults separate from terrain regions.
      case 'region': return { fill: '#7050a8', stroke: '#4a3070', fillOpacity: DEFAULT_REGION_FILL_OPACITY, name: '' }
      case 'wall': {
        // Local and interior walls share the material preset system; interior
        // walls keep semanticType 'wall' so door/window placement is unaffected.
        if (isLocalMap || isInteriorMap) {
          const material = getLocalWallMaterial(localWallMaterial)
          return { stroke: material.stroke, highlight: material.highlight, mortar: material.mortar, lineThickness: localWallThickness, semanticType: isLocalMap ? 'localWall' : 'wall', wallMaterial: material.value, lineStyle: wallLineStyle }
        }
        return { stroke: stylePreset === 'blueprint' ? '#d7e4ec' : '#30343a', highlight: stylePreset === 'blueprint' ? '#88aeca' : '#6b7078', lineThickness: 14, semanticType: 'wall', lineStyle: wallLineStyle }
      }
      case 'water': return { fill: '#73b8cf', stroke: '#2f769f', lineThickness: 3, organicEdges: true, waveTexture: true }
      case 'river': return { fill: '#7faec0', stroke: '#2f5f78', lineThickness: 7 }
      case 'road': return { stroke: '#8b6030', borderStroke: '#2c1a0a', highlight: '#f0d8a0', lineThickness: 5 }
      case 'path': return { stroke: '#8f7652', borderStroke: '#6a4b2d', highlight: '#d8c095', lineThickness: localPathThickness, semanticType: 'localPath' }
      case 'border': return { stroke: '#9050a0', lineThickness: 4 }
      case 'mountain': return { fill: '#7a7060', stroke: '#3a3228', lineThickness: 22 }
      default: return {}
    }
  }

  // ── Place objects ───────────────────────────────────────────────────────────

  function placeStampAt(rawPoint) {
    const point = getSnappedPoint(rawPoint)
    const stamp = STAMP_LIBRARY.find(s => s.id === effectiveSelectedStampId) || filteredStamps[0] || STAMP_LIBRARY[0]
    const size = stamp.size || 80
    const maxZ = Math.max(0, ...objectsRef.current.map(o => o.zIndex || 0)) + 1
    const obj = normalizeObject({ id: uid('stamp'), type: 'stamp', x: point.x, y: point.y, width: size, height: size, zIndex: maxZ, properties: { stampId: stamp.id, name: stamp.name, showLabel: false } })
    updateObjects(cur => [...cur, obj])
    setSelectedIds([obj.id])
    setRecentStamps(prev => { const next = [stamp.id, ...prev.filter(id => id !== stamp.id)].slice(0, 10); saveJson('yow_map_recent_stamps', next); return next })
  }

  function placeLocationAt(point, config) {
    let locationId = config.linkToId || null
    let locationName = config.name.trim() || 'Location'
    if (config.createNew && config.name.trim() && saveLocation) {
      const created = saveLocation({ name: config.name.trim(), category: 'Other', description: '' })
      if (created?.id) { locationId = created.id; locationName = created.name || config.name.trim() }
    } else if (config.linkToId) {
      const linked = (project.locations || []).find(l => l.id === config.linkToId)
      if (linked) locationName = linked.name || locationName
    }
    const size = config.size || 64
    const maxZ = Math.max(0, ...objectsRef.current.map(o => o.zIndex || 0)) + 1
    const obj = normalizeObject({
      id: uid('location'), type: 'location', x: point.x, y: point.y,
      width: size, height: size, zIndex: maxZ,
      properties: {
        name: locationName,
        markerIcon: config.markerIcon || 'pin',
        iconSize: Number(config.iconSize) || size,
        fill: config.fill || DEFAULT_LOCATION_FILL,
        stroke: config.stroke || DEFAULT_LOCATION_STROKE,
        labelFontSize: Number(config.labelFontSize) || 18,
        labelColor: config.labelColor || DEFAULT_LOCATION_LABEL_COLOR,
        labelOutlineColor: config.labelOutlineColor || DEFAULT_LOCATION_LABEL_OUTLINE,
        showLabel: true,
      },
      linkedEntity: locationId ? { entityType: 'location', entityId: locationId } : null,
    })
    updateObjects(cur => [...cur, obj])
    setSelectedIds([obj.id])
  }

  function placeLabelAt(point, config) {
    const text = config.text.trim()
    if (!text) return
    const fontSize = config.fontSize || 40
    const w = Math.max(180, text.length * fontSize * 0.62)
    const h = Math.max(64, fontSize * 1.7)
    const maxZ = Math.max(0, ...objectsRef.current.map(o => o.zIndex || 0)) + 1
    const obj = normalizeObject({
      id: uid('label'), type: 'label', x: point.x, y: point.y,
      width: w, height: h, zIndex: maxZ,
      properties: { name: text, text, ...config },
    })
    updateObjects(cur => [...cur, obj])
    setSelectedIds([obj.id])
  }

  function placeNoteAt(point, config) {
    const maxZ = Math.max(0, ...objectsRef.current.map(o => o.zIndex || 0)) + 1
    const obj = normalizeObject({
      id: uid('note'), type: 'note', x: point.x, y: point.y,
      width: 80, height: 88, zIndex: maxZ,
      properties: { title: config.title || '', name: config.title || 'Note', notes: config.body || '', gmOnly: Boolean(config.gmOnly), visibility: config.gmOnly ? 'private' : (config.visibility || 'private') },
    })
    updateObjects(cur => [...cur, obj])
    setSelectedIds([obj.id])
  }

  function findNearestWallOpening(rawPoint) {
    const walls = objectsRef.current.filter(o => o.type === 'wall' && o.geometry?.points?.length >= 2)
    let best = null
    walls.forEach(wall => {
      const pts = wall.geometry.points || []
      for (let i = 1; i < pts.length; i++) {
        const a = pts[i - 1]
        const b = pts[i]
        const projected = projectPointToSegment(rawPoint, a, b)
        if (!best || projected.distance < best.distance) {
          best = { ...projected, wall, a, b }
        }
      }
    })
    if (!best || best.distance > OPENING_PLACE_RADIUS / Math.max(viewRef.current.zoom || 1, 0.45)) return null
    const wallThickness = Number(best.wall.properties?.lineThickness) || 14
    const openingLength = selectedOpeningKind === 'window' ? 96 : 76
    const halfT = Math.min(0.42, (openingLength / 2) / Math.max(best.segmentLength, 1))
    const t1 = clamp(best.t - halfT, 0, 1)
    const t2 = clamp(best.t + halfT, 0, 1)
    return {
      wall: best.wall,
      wallThickness,
      points: [
        { x: best.a.x + (best.b.x - best.a.x) * t1, y: best.a.y + (best.b.y - best.a.y) * t1 },
        { x: best.a.x + (best.b.x - best.a.x) * t2, y: best.a.y + (best.b.y - best.a.y) * t2 },
      ],
    }
  }

  function placeOpeningAt(rawPoint) {
    const match = findNearestWallOpening(rawPoint)
    if (!match) return
    const maxZ = Math.max(0, ...objectsRef.current.map(o => o.zIndex || 0)) + 1
    const obj = normalizeObject({
      id: uid('opening'),
      type: 'opening',
      x: 0, y: 0, width: 0, height: 0,
      zIndex: maxZ,
      geometry: { type: 'path', points: match.points },
      properties: {
        name: selectedOpeningKind === 'window' ? 'Window' : 'Door',
        openingKind: selectedOpeningKind,
        doorSwing: selectedDoorSwing,
        wallId: match.wall.id,
        wallThickness: match.wallThickness,
      },
    })
    updateObjects(cur => [...cur, obj])
    setSelectedIds([obj.id])
  }

  // ── Pointer events ──────────────────────────────────────────────────────────

  // Double-click on a line object selects just the segment under the cursor.
  // Single click keeps its existing whole-object behaviour.
  function handleDoubleClick(e) {
    if (!activeMap || editorMode === 'view' || mode !== 'select') return
    const point = screenToMap(e.clientX, e.clientY, viewportRef.current, viewRef.current)
    const tolerance = 12 / (viewRef.current.zoom || 1)
    for (const o of [...visibleObjectsRef.current].reverse()) {
      if (!LINE_SEGMENT_TYPES.has(o.type) || o.locked) continue
      const pts = o.geometry?.points
      if (!pts || pts.length < 2) continue
      const hitWidth = (Number(o.properties?.lineThickness) || 6) / 2 + tolerance
      let best = null
      for (let i = 0; i < pts.length - 1; i++) {
        const proj = projectPointToSegment(point, pts[i], pts[i + 1])
        if (proj.distance <= hitWidth && (!best || proj.distance < best.distance)) {
          best = { index: i, distance: proj.distance }
        }
      }
      if (best) {
        setSelectedIds([o.id])
        setSelectedSegment({ objectId: o.id, index: best.index })
        return
      }
    }
    setSelectedSegment(null)
  }

  function handlePointerDown(e) {
    if (!activeMap || e.button !== 0) return
    const vp = viewportRef.current
    const point = screenToMap(e.clientX, e.clientY, vp, viewRef.current)
    e.currentTarget.setPointerCapture(e.pointerId)
    // Single click always returns to whole-object selection; a double-click
    // re-selects the segment right after.
    if (selectedSegmentRef.current) setSelectedSegment(null)

    // view mode — pan or navigate to linked entry on click
    if (editorMode === 'view') {
      if (e.altKey || spacePressedRef.current) {
        interactionRef.current = { type: 'pan', startX: e.clientX, startY: e.clientY, startPan: viewRef.current.pan }
        return
      }
      const hit = hitTest(point)
      if (!isInteriorMap && hit?.linkedEntity?.entityType === 'location') {
        const locId = hit.linkedEntity.entityId
        if (locId) {
          setSelectedLocationId?.(locId)
          window.dispatchEvent(new CustomEvent('switch-section', { detail: { section: 'locations' } }))
        }
      }
      interactionRef.current = { type: 'pan', startX: e.clientX, startY: e.clientY, startPan: viewRef.current.pan }
      return
    }

    // pan modes
    if (mode === 'pan' || e.altKey || spacePressedRef.current || e.shiftKey) {
      interactionRef.current = { type: 'pan', startX: e.clientX, startY: e.clientY, startPan: viewRef.current.pan }
      return
    }
    if (mode === 'zoom') { zoomAt(e.clientX, e.clientY, e.shiftKey ? 0.78 : 1.22); return }

    // drawing tools
    if (POINT_DRAW_TOOLS.has(mode)) {
      if (FREEHAND_DRAW_TOOLS.has(mode) && polygonDrawMode === 'freehand') {
        startFreehandDraft(point, mode)
      } else {
        startOrExtendDraft(point, mode, e.detail >= 2)
      }
      return
    }

    if (mode === 'opening') { placeOpeningAt(point); return }

    // stamp
    if (mode === 'stamp') { placeStampAt(point); return }

    // location
    if (mode === 'location') {
      setLocConfig({
        name: '',
        markerIcon: 'pin',
        size: 64,
        iconSize: DEFAULT_LOCATION_ICON_SIZE,
        fill: DEFAULT_LOCATION_FILL,
        stroke: DEFAULT_LOCATION_STROKE,
        labelFontSize: 18,
        labelColor: DEFAULT_LOCATION_LABEL_COLOR,
        labelOutlineColor: DEFAULT_LOCATION_LABEL_OUTLINE,
        linkToId: '',
        createNew: false,
      })
      setModal({ kind: 'location', point: getSnappedPoint(point) })
      return
    }

    // label
    if (mode === 'label') {
      setLabelConfig(c => ({ ...c, text: '' }))
      setModal({ kind: 'label', point: getSnappedPoint(point) })
      return
    }

    // note
    if (mode === 'note') {
      setNoteConfig({ title: '', body: '', gmOnly: false, visibility: 'private' })
      setModal({ kind: 'note', point: getSnappedPoint(point) })
      return
    }

    // select
    const labelHandleHit = hitTestTerritoryLabelHandle(point)
    if (labelHandleHit) {
      const object = objectByIdRef.current.get(labelHandleHit.objectId)
      if (!object) return
      interactionRef.current = {
        type: 'label-position-drag',
        objectId: object.id,
        startClientX: e.clientX,
        startClientY: e.clientY,
        hasMoved: false,
        startPoint: point,
        startOffsetX: object.properties?.labelOffsetX || 0,
        startOffsetY: object.properties?.labelOffsetY || 0,
      }
      return
    }

    const resizeHit = hitTestResizeHandle(point)
    if (resizeHit) {
      const object = objectByIdRef.current.get(selectedIdsRef.current[0])
      if (!object) return
      setHoveredResizeHandle({ objectId: object.id, handle: resizeHit.handle })
      if (object.type === 'stamp' && !object.geometry) {
        interactionRef.current = {
          type: 'stamp-resize',
          objectId: object.id,
          handle: resizeHit.handle,
          anchorX: resizeHit.anchorX,
          anchorY: resizeHit.anchorY,
          startClientX: e.clientX,
          startClientY: e.clientY,
          hasMoved: false,
          startObject: { x: object.x || 0, y: object.y || 0, width: object.width || 80, height: object.height || object.width || 80 },
        }
        return
      }
      interactionRef.current = {
        type: 'geometry-resize',
        objectId: object.id,
        handle: resizeHit.handle,
        anchorX: resizeHit.anchorX,
        anchorY: resizeHit.anchorY,
        startClientX: e.clientX,
        startClientY: e.clientY,
        hasMoved: false,
        startPoints: (object.geometry?.points || []).map(p => ({ ...p })),
      }
      return
    }

    const handleHit = hitTestPointHandle(point)
    if (handleHit) {
      const object = objectByIdRef.current.get(handleHit.objectId)
      if (!object) return
      setSelectedIds([object.id])
      setHoveredPointHandle(handleHit)
      interactionRef.current = {
        type: 'point-drag',
        objectId: object.id,
        pointIndex: handleHit.pointIndex,
        startClientX: e.clientX,
        startClientY: e.clientY,
        hasMoved: false,
        startPoint: point,
        startPoints: (object.geometry?.points || []).map(p => ({ ...p })),
      }
      return
    }

    const hit = hitTest(point)
    if (hit && !hit.locked) {
      const additive = e.shiftKey || e.metaKey || e.ctrlKey
      const next = additive
        ? (selectedIdsRef.current.includes(hit.id) ? selectedIdsRef.current.filter(id => id !== hit.id) : [...selectedIdsRef.current, hit.id])
        : selectedIdsRef.current.includes(hit.id) ? selectedIdsRef.current : [hit.id]
      const nextIds = new Set(next)
      const startObjectsById = new Map(objectsRef.current
        .filter(object => nextIds.has(object.id))
        .map(object => [object.id, { id: object.id, x: object.x || 0, y: object.y || 0, geometry: object.geometry }]))
      setSelectedIds(next)
      interactionRef.current = {
        type: 'drag',
        startClientX: e.clientX, startClientY: e.clientY, hasMoved: false, startPoint: point,
        startObjectsById,
      }
      return
    }
    if (!e.shiftKey) setSelectedIds([])
    setHoveredId(null)
  }

  function handlePointerMove(e) {
    const ia = interactionRef.current
    const pt = screenToMap(e.clientX, e.clientY, viewportRef.current, viewRef.current)

    // view mode hover
    if (editorMode === 'view') {
      if (ia?.type === 'pan') {
        const next = { ...viewRef.current, pan: { x: ia.startPan.x + e.clientX - ia.startX, y: ia.startPan.y + e.clientY - ia.startY } }
        viewRef.current = next
        requestRender()
        return
      }
      const hit = hitTest(pt)
      const hasLink = !isInteriorMap && hit?.linkedEntity?.entityType === 'location'
      if (hoveredIdRef.current !== (hit?.id || null)) setHoveredId(hit?.id || null)
      if (hasLink) {
        setViewTooltip({ x: e.clientX, y: e.clientY, object: hit })
      } else {
        setViewTooltip(null)
      }
      return
    }

    if (!ia && ['stamp', 'location', 'opening'].includes(mode) && !modal) {
      cursorMapPointRef.current = mode === 'opening' ? pt : getSnappedPoint(pt)
      requestRender()
    }

    if (!ia) {
      if (draftRef.current?.points?.length && POINT_DRAW_TOOLS.has(mode)) {
        setDraft(cur => {
          if (!cur) return cur
          const preview = getSnappedPoint(pt)
          const first = cur.points?.[0]
          const closesOnOrigin = cur.kind === 'water' && cur.points.length >= 3 && first &&
            Math.hypot(preview.x - first.x, preview.y - first.y) <= Math.max(10, 18 / viewRef.current.zoom)
          return { ...cur, preview, closed: closesOnOrigin || (POLYGON_DRAW_TOOLS.has(cur.kind) && cur.points.length >= 3) }
        })
        setHoveredId(null)
        return
      }
      if (mode === 'select') {
        const resizeHit = hitTestResizeHandle(pt)
        if (resizeHit) {
          const objectId = selectedIdsRef.current[0]
          if (hoveredResizeHandle?.objectId !== objectId || hoveredResizeHandle?.handle !== resizeHit.handle) {
            setHoveredResizeHandle({ objectId, handle: resizeHit.handle })
          }
          setHoveredPointHandle(null)
          setHoveredId(null)
          return
        }
        if (hoveredResizeHandle) setHoveredResizeHandle(null)
        const handleHit = hitTestPointHandle(pt)
        if (handleHit) {
          if (hoveredPointHandle?.objectId !== handleHit.objectId || hoveredPointHandle?.pointIndex !== handleHit.pointIndex) {
            setHoveredPointHandle(handleHit)
          }
          setHoveredId(null)
          return
        }
        if (hoveredPointHandle) setHoveredPointHandle(null)
        const hit = hitTest(pt)
        if (hoveredIdRef.current !== (hit?.id || null)) setHoveredId(hit?.id || null)
      }
      return
    }

    if (ia.type === 'pan') {
      const next = { ...viewRef.current, pan: { x: ia.startPan.x + e.clientX - ia.startX, y: ia.startPan.y + e.clientY - ia.startY } }
      viewRef.current = next
      requestRender()
      return
    }

    if (ia.type === 'drag') {
      const screenDist = Math.hypot(e.clientX - ia.startClientX, e.clientY - ia.startClientY)
      if (!ia.hasMoved && screenDist < DRAG_THRESHOLD_PX) return
      if (!ia.hasMoved) { takeSnapshot(); ia.hasMoved = true }
      const dx = pt.x - ia.startPoint.x, dy = pt.y - ia.startPoint.y
      updateObjectsTransient(cur => cur.map(o => {
        const start = ia.startObjectsById.get(o.id)
        if (!start || o.locked) return o
        if (o.geometry?.type === 'polygon' || o.geometry?.type === 'path') {
          const pts = start.geometry?.points || []
          return { ...o, geometry: { ...o.geometry, points: pts.map(p => getSnappedPoint({ x: p.x + dx, y: p.y + dy })) } }
        }
        return { ...o, ...getSnappedPoint({ x: start.x + dx, y: start.y + dy }) }
      }))
    }

    if (ia.type === 'point-drag') {
      const screenDist = Math.hypot(e.clientX - ia.startClientX, e.clientY - ia.startClientY)
      if (!ia.hasMoved && screenDist < DRAG_THRESHOLD_PX) return
      if (!ia.hasMoved) { takeSnapshot(); ia.hasMoved = true }
      const dx = pt.x - ia.startPoint.x
      const dy = pt.y - ia.startPoint.y
      updateObjectsTransient(cur => cur.map(o => {
        if (o.id !== ia.objectId || o.locked) return o
        const points = ia.startPoints.map((p, index) => (
          index === ia.pointIndex ? getSnappedPoint({ x: p.x + dx, y: p.y + dy }) : p
        ))
        return { ...o, geometry: { ...o.geometry, points } }
      }))
    }

    if (ia.type === 'label-position-drag') {
      const screenDist = Math.hypot(e.clientX - ia.startClientX, e.clientY - ia.startClientY)
      if (!ia.hasMoved && screenDist < DRAG_THRESHOLD_PX) return
      if (!ia.hasMoved) { takeSnapshot(); ia.hasMoved = true }
      const dx = pt.x - ia.startPoint.x
      const dy = pt.y - ia.startPoint.y
      updateObjectsTransient(cur => cur.map(o => {
        if (o.id !== ia.objectId || o.locked) return o
        return {
          ...o,
          properties: {
            ...(o.properties || {}),
            labelOffsetX: ia.startOffsetX + dx,
            labelOffsetY: ia.startOffsetY + dy,
          },
        }
      }))
    }

    if (ia.type === 'geometry-resize') {
      const screenDist = Math.hypot(e.clientX - ia.startClientX, e.clientY - ia.startClientY)
      if (!ia.hasMoved && screenDist < DRAG_THRESHOLD_PX) return
      if (!ia.hasMoved) { takeSnapshot(); ia.hasMoved = true }
      updateObjectsTransient(cur => cur.map(o => {
        if (o.id !== ia.objectId || o.locked) return o
        const points = resizeGeometryPoints(ia.startPoints, ia, pt)
        return { ...o, geometry: { ...o.geometry, points } }
      }))
    }

    if (ia.type === 'stamp-resize') {
      const screenDist = Math.hypot(e.clientX - ia.startClientX, e.clientY - ia.startClientY)
      if (!ia.hasMoved && screenDist < DRAG_THRESHOLD_PX) return
      if (!ia.hasMoved) { takeSnapshot(); ia.hasMoved = true }
      updateObjectsTransient(cur => cur.map(o => {
        if (o.id !== ia.objectId || o.locked) return o
        return { ...o, ...resizeStampObject(ia.startObject, ia, pt) }
      }))
    }

    if (ia.type === 'freehand-draw') {
      appendFreehandPoint(pt)
    }
  }

  function handlePointerUp(e) {
    if (editorMode === 'view') {
      if (interactionRef.current?.type === 'pan') setView(viewRef.current)
      interactionRef.current = null
      e.currentTarget.releasePointerCapture?.(e.pointerId)
      return
    }
    if (interactionRef.current?.type === 'freehand-draw') {
      const curDraft = {
        kind: interactionRef.current.tool,
        points: interactionRef.current.points || [],
        drawMode: 'freehand',
      }
      interactionRef.current = null
      if (curDraft.kind === 'water' && curDraft.points.length >= 3) {
        const first = curDraft.points[0]
        const last = curDraft.points[curDraft.points.length - 1]
        curDraft.closed = Math.hypot(last.x - first.x, last.y - first.y) <= Math.max(18, 28 / viewRef.current.zoom)
      }
      const minPoints = POLYGON_DRAW_TOOLS.has(curDraft.kind) ? 3 : 2
      if (curDraft?.points?.length >= minPoints) completeDraft(curDraft)
      else setDraft(null)
      e.currentTarget.releasePointerCapture?.(e.pointerId)
      return
    }
    if (interactionRef.current?.type === 'drag' && !interactionRef.current.hasMoved && selectedIds.length === 1) {
      // single click on already-selected object — keep selection
    }
    if (['drag', 'point-drag', 'label-position-drag', 'geometry-resize', 'stamp-resize'].includes(interactionRef.current?.type) && interactionRef.current.hasMoved) {
      persistObjects(objectsRef.current)
    }
    if (interactionRef.current?.type === 'pan') {
      setView(viewRef.current)
    }
    interactionRef.current = null
    e.currentTarget.releasePointerCapture?.(e.pointerId)
  }

  function handlePointerLeave() {
    if (!interactionRef.current) {
      cursorMapPointRef.current = null
      setHoveredId(null)
      setHoveredPointHandle(null)
      setHoveredResizeHandle(null)
      setViewTooltip(null)
      requestRender()
    }
  }

  // Wheel zoom is attached via useEffect with passive:false so preventDefault works.
  // The JSX onWheel is a no-op fallback.
  useEffect(() => {
    const vp = viewportRef.current
    if (!vp) return
    const onWheel = (e) => {
      e.preventDefault()
      const norm = Math.max(-120, Math.min(120, e.deltaY))
      const factor = Math.exp(-norm * WHEEL_ZOOM_INTENSITY)
      const rect = vp.getBoundingClientRect()
      const cur = viewRef.current
      const nextZoom = clamp(cur.zoom * factor, MIN_ZOOM, MAX_ZOOM)
      const sx = e.clientX - rect.left, sy = e.clientY - rect.top
      const mapX = (sx - cur.pan.x) / cur.zoom, mapY = (sy - cur.pan.y) / cur.zoom
      const next = { zoom: nextZoom, pan: { x: sx - mapX * nextZoom, y: sy - mapY * nextZoom } }
      viewRef.current = next
      setView(next)
    }
    vp.addEventListener('wheel', onWheel, { passive: false })
    return () => vp.removeEventListener('wheel', onWheel)
  }, [])

  // ── Export PNG ──────────────────────────────────────────────────────────────

  function exportPng() {
    const scale = 2
    const exportCanvas = document.createElement('canvas')
    exportCanvas.width = MAP_W * scale; exportCanvas.height = MAP_H * scale
    const ctx = exportCanvas.getContext('2d')
    ctx.scale(scale, scale)
    const opts = { style: stylePreset, mapType: activeMapType }
    drawBackground(ctx, MAP_W, MAP_H, stylePreset, baseLayer)
    ctx.save(); ctx.beginPath(); ctx.rect(0, 0, MAP_W, MAP_H); ctx.clip()
    drawMovementGrid(ctx, MAP_W, MAP_H, gridSettings)
    drawObjectsInLayerOrder(ctx, visibleObjects.filter(isMapObjectExportable), [], opts)
    ctx.restore()
    exportCanvas.toBlob(blob => {
      if (!blob) return
      downloadBlob(blob, `${(activeMap.name || 'map').replace(/[^a-z0-9]+/gi, '-').toLowerCase()}.png`)
    }, 'image/png')
  }

  function handleCreateMap({ name, mapType, stylePreset }) {
    const id = addMap(name, mapType, { stylePreset })
    if (id) setTimeout(() => selectMap(id), 0)
    setShowNewMapModal(false)
  }

  // ── Modals ──────────────────────────────────────────────────────────────────

  const canUndo = historyVersion >= 0 && undoStackRef.current.length > 0
  const canRedo = historyVersion >= 0 && redoStackRef.current.length > 0

  const canvasCursor = editorMode === 'view'
    ? (viewTooltip ? 'pointer' : spacePressedRef.current ? 'grab' : 'default')
    : mode === 'pan' || spacePressedRef.current ? 'grab'
    : mode === 'zoom' ? 'zoom-in'
    : mode === 'select' ? (hoveredResizeHandle ? `${hoveredResizeHandle.handle}-resize` : hoveredPointHandle ? 'grab' : hoveredId ? 'move' : 'default')
    : POINT_DRAW_TOOLS.has(mode) ? 'crosshair'
    : ['stamp', 'location', 'label', 'note', 'opening'].includes(mode) ? 'crosshair'
    : 'default'

  // ── Render ──────────────────────────────────────────────────────────────────

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: '#2a2e33', overflow: 'hidden' }}>

      {/* Command bar */}
      <div style={{ height: CMD_H, background: 'var(--surface)', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', gap: 8, padding: '0 12px', flexShrink: 0, zIndex: 10 }}>
        {/* Mode toggle */}
        <div style={{ display: 'flex', background: 'var(--surface2)', borderRadius: 7, padding: 2, gap: 2, border: '1px solid var(--border)' }}>
          {[['create', '✏️ Create'], ['view', '👁 View']].map(([m, label]) => (
            <button
              key={m}
              onClick={() => { setEditorMode(m); setViewTooltip(null) }}
              style={{
                padding: '3px 10px', borderRadius: 5, border: 'none', cursor: 'pointer',
                fontFamily: 'inherit', fontSize: 11, fontWeight: editorMode === m ? 700 : 400,
                background: editorMode === m ? 'var(--accent)' : 'transparent',
                color: editorMode === m ? '#fff' : 'var(--muted)',
                transition: 'background 0.12s, color 0.12s',
              }}
            >{label}</button>
          ))}
        </div>
        <div style={{ width: 1, background: 'var(--border)', height: 20 }} />
        {/* Map switcher */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <select
            value={activeMap.id}
            onChange={e => selectMap(e.target.value)}
            style={{ border: '1px solid var(--border)', background: 'var(--surface2)', color: 'var(--text)', borderRadius: 6, padding: '4px 8px', fontSize: 16, fontFamily: 'inherit', fontWeight: 600, maxWidth: 160 }}
          >
            {(project.maps || []).map(m => <option key={m.id} value={m.id}>{m.name || 'Untitled'}</option>)}
          </select>
          <button className="btn btn-secondary btn-sm" title="New map" onClick={() => setShowNewMapModal(true)} style={{ fontSize: 13, lineHeight: 1 }}>+</button>
        </div>
        <span style={{ fontSize: 10, color: 'var(--muted)', border: '1px solid var(--border)', borderRadius: 4, padding: '1px 5px', textTransform: 'uppercase', letterSpacing: '0.04em' }}>{activeMapType}</span>
        <div style={{ flex: 1 }} />
        <button className="btn btn-secondary btn-sm" onClick={undo} disabled={!canUndo} title="Undo (⌘Z)">↶</button>
        <button className="btn btn-secondary btn-sm" onClick={redo} disabled={!canRedo} title="Redo (⌘⇧Z)">↷</button>
        <div style={{ width: 1, background: 'var(--border)', height: 20, margin: '0 4px' }} />
        <button className="btn btn-secondary btn-sm" onClick={() => zoomCenter(0.82)} title="Zoom out">−</button>
        <span style={{ fontSize: 12, color: 'var(--muted)', minWidth: 42, textAlign: 'center' }}>{Math.round(view.zoom * 100)}%</span>
        <button className="btn btn-secondary btn-sm" onClick={() => zoomCenter(1.2)} title="Zoom in">+</button>
        <button className="btn btn-secondary btn-sm" onClick={() => fitCanvas()} title="Fit to screen" style={{ fontSize: 11 }}>Fit</button>
        <div style={{ width: 1, background: 'var(--border)', height: 20, margin: '0 4px' }} />
        <select
          value={stylePreset}
          onChange={e => persistMeta({ stylePreset: e.target.value })}
          style={{ height: 28, border: '1px solid var(--border)', background: 'var(--surface2)', color: 'var(--text)', borderRadius: 6, padding: '0 8px', fontSize: 16, fontFamily: 'inherit' }}
        >
          {STYLE_PRESETS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
        </select>
        <button className="btn btn-primary btn-sm" onClick={exportPng} style={{ fontSize: 12 }}>Export PNG</button>
      </div>

      {/* Body */}
      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>

        {/* Left toolbar — hidden in view mode */}
        <div style={{ width: editorMode === 'view' ? 0 : TOOLBAR_W, overflow: 'hidden', background: 'var(--surface)', borderRight: editorMode === 'view' ? 'none' : '1px solid var(--border)', display: 'flex', flexDirection: 'column', alignItems: 'stretch', padding: editorMode === 'view' ? 0 : '4px 5px', flexShrink: 0, overflowX: 'hidden', overflowY: 'auto', transition: 'width 0.15s' }}>
          {activeTools.map((tool, idx) => {
            const prevTool = activeTools[idx - 1]
            const showSep = prevTool && prevTool.group !== tool.group
            const isActive = mode === tool.id
            return (
              <div key={tool.id} style={{ display: 'contents' }}>
                {showSep && <div style={{ height: 1, background: 'var(--border)', flexShrink: 0, margin: '2px 0' }} />}
                <button
                  title={tool.label}
                  onClick={() => { setMode(isActive ? 'select' : tool.id); setDraft(null) }}
                  style={{
                    flex: 1,
                    minHeight: 40,
                    flexShrink: 0,
                    borderRadius: 7,
                    border: isActive ? '1.5px solid var(--accent)' : '1.5px solid transparent',
                    cursor: 'pointer',
                    display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
                    gap: 2, padding: '4px 2px',
                    fontFamily: 'inherit',
                    background: isActive ? 'color-mix(in srgb, var(--accent) 18%, var(--surface2))' : 'transparent',
                    color: isActive ? 'var(--accent)' : 'var(--muted)',
                    transition: 'background 0.1s, color 0.1s, border-color 0.1s',
                  }}
                >
                  <span aria-hidden="true" style={{ fontSize: 14, lineHeight: 1 }}>{tool.icon}</span>
                  <span style={{ fontSize: 9, lineHeight: 1, fontWeight: isActive ? 700 : 400, letterSpacing: '0.01em', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: 72 }}>{tool.label}</span>
                </button>
              </div>
            )
          })}

          {/* Terrain type picker */}
          {mode === 'terrain' && (
            <div
              onPointerDown={e => e.stopPropagation()}
              onWheelCapture={e => e.stopPropagation()}
              onWheel={e => e.stopPropagation()}
              style={{ position: 'absolute', left: TOOLBAR_W, top: CMD_H + 8, width: 196, maxHeight: 'min(340px, calc(100vh - 156px))', overflow: 'hidden', boxSizing: 'border-box', background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 10, padding: 12, zIndex: 20, display: 'flex', flexDirection: 'column', gap: 6, boxShadow: 'var(--shadow-md)' }}
            >
              <div style={{ fontWeight: 700, fontSize: 12, color: 'var(--text)', marginBottom: 2 }}>Terrain type</div>
              <div style={{ fontSize: 11, color: 'var(--muted)', lineHeight: 1.4 }}>Click to select, then draw on the canvas.</div>
              <div style={{ flex: '1 1 auto', minHeight: 0, overflowY: 'auto', overscrollBehavior: 'contain', display: 'flex', flexDirection: 'column', gap: 6, paddingRight: 4 }}>
                {TERRAIN_TYPES.map(t => {
                  const isActive = selectedTerrainType === t.value
                  return (
                    <button
                      key={t.value}
                      onClick={() => setSelectedTerrainType(t.value)}
                      style={{
                        display: 'flex', alignItems: 'center', gap: 10, padding: '7px 10px',
                        borderRadius: 7, border: `2px solid ${isActive ? 'var(--accent)' : 'var(--border)'}`,
                        background: isActive ? 'color-mix(in srgb, var(--accent) 12%, var(--surface2))' : 'var(--surface2)',
                        cursor: 'pointer', fontFamily: 'inherit', textAlign: 'left',
                      }}
                    >
                      <span style={{ width: 18, height: 18, borderRadius: 4, background: t.color, flexShrink: 0, border: '1px solid rgba(0,0,0,0.18)' }} />
                      <span style={{ fontSize: 12, fontWeight: isActive ? 700 : 400, color: isActive ? 'var(--accent)' : 'var(--text)' }}>{t.label}</span>
                    </button>
                  )
                })}
              </div>
            </div>
          )}

          {FREEHAND_DRAW_TOOLS.has(mode) && (
            <div style={{ position: 'absolute', left: TOOLBAR_W, top: mode === 'terrain' ? CMD_H + 364 : CMD_H + 8, width: 196, background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 10, padding: 12, zIndex: 20, display: 'flex', flexDirection: 'column', gap: 8, boxShadow: 'var(--shadow-md)' }}>
              <div style={{ fontWeight: 700, fontSize: 12, color: 'var(--text)' }}>Draw mode</div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
                {[
                  ['point', 'Point'],
                  ['freehand', 'Freehand'],
                ].map(([value, label]) => {
                  const isActive = polygonDrawMode === value
                  return (
                    <button
                      key={value}
                      type="button"
                      onClick={() => { setPolygonDrawMode(value); setDraft(null) }}
                      aria-pressed={isActive}
                      style={{
                        minHeight: 30,
                        borderRadius: 7,
                        border: `2px solid ${isActive ? 'var(--accent)' : 'var(--border)'}`,
                        background: isActive ? 'color-mix(in srgb, var(--accent) 12%, var(--surface2))' : 'var(--surface2)',
                        color: isActive ? 'var(--accent)' : 'var(--text)',
                        cursor: 'pointer',
                        fontFamily: 'inherit',
                        fontSize: 11,
                        fontWeight: isActive ? 700 : 500,
                      }}
                    >
                      {label}
                    </button>
                  )
                })}
              </div>
              {isInteriorMap && mode === 'region' && (
                <>
                  <div style={{ height: 1, background: 'var(--border)', margin: '2px 0' }} />
                  <div style={{ fontWeight: 700, fontSize: 12, color: 'var(--text)' }}>Room edges</div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
                    {[
                      ['straight', 'Straight'],
                      ['curved', 'Curved'],
                    ].map(([value, label]) => {
                      const isActive = roomLineStyle === value
                      return (
                        <button
                          key={value}
                          type="button"
                          onClick={() => setRoomLineStyle(value)}
                          aria-pressed={isActive}
                          style={{
                            minHeight: 30,
                            borderRadius: 7,
                            border: `2px solid ${isActive ? 'var(--accent)' : 'var(--border)'}`,
                            background: isActive ? 'color-mix(in srgb, var(--accent) 12%, var(--surface2))' : 'var(--surface2)',
                            color: isActive ? 'var(--accent)' : 'var(--text)',
                            cursor: 'pointer',
                            fontFamily: 'inherit',
                            fontSize: 11,
                            fontWeight: isActive ? 700 : 500,
                          }}
                        >
                          {label}
                        </button>
                      )
                    })}
                  </div>
                </>
              )}
            </div>
          )}

          {mode === 'wall' && (isInteriorMap || isLocalMap) && (
            <div style={{ position: 'absolute', left: TOOLBAR_W, top: CMD_H + 8, width: 196, background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 10, padding: 12, zIndex: 20, display: 'flex', flexDirection: 'column', gap: 8, boxShadow: 'var(--shadow-md)' }}>
              <div style={{ fontWeight: 700, fontSize: 12, color: 'var(--text)' }}>Wall lines</div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
                {[
                  ['straight', 'Straight'],
                  ['curved', 'Curved'],
                ].map(([value, label]) => {
                  const isActive = wallLineStyle === value
                  return (
                    <button
                      key={value}
                      type="button"
                      onClick={() => setWallLineStyle(value)}
                      aria-pressed={isActive}
                      style={{
                        minHeight: 30,
                        borderRadius: 7,
                        border: `2px solid ${isActive ? 'var(--accent)' : 'var(--border)'}`,
                        background: isActive ? 'color-mix(in srgb, var(--accent) 12%, var(--surface2))' : 'var(--surface2)',
                        color: isActive ? 'var(--accent)' : 'var(--text)',
                        cursor: 'pointer',
                        fontFamily: 'inherit',
                        fontSize: 11,
                        fontWeight: isActive ? 700 : 500,
                      }}
                    >
                      {label}
                    </button>
                  )
                })}
              </div>
              {(isLocalMap || isInteriorMap) && (
                <>
                  <div style={{ height: 1, background: 'var(--border)', margin: '2px 0' }} />
                  <label style={{ display: 'grid', gap: 4, fontSize: 11, color: 'var(--muted)', fontWeight: 700 }}>
                    Material
                    <select
                      value={localWallMaterial}
                      onChange={e => setLocalWallMaterial(e.target.value)}
                      style={{ ...inputStyle, width: '100%', minWidth: 0, fontSize: 16, padding: '5px 8px' }}
                    >
                      {LOCAL_WALL_MATERIALS.map(material => <option key={material.value} value={material.value}>{material.label}</option>)}
                    </select>
                  </label>
                  <label style={{ display: 'grid', gap: 4, fontSize: 11, color: 'var(--muted)', fontWeight: 700 }}>
                    Wall size
                    <SliderInput min={6} max={48} step={1} value={localWallThickness} onChange={e => setLocalWallThickness(Math.max(6, Number(e.target.value)))} />
                  </label>
                </>
              )}
            </div>
          )}

          {mode === 'path' && isLocalMap && (
            <div style={{ position: 'absolute', left: TOOLBAR_W, top: CMD_H + 8, width: 196, background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 10, padding: 12, zIndex: 20, display: 'flex', flexDirection: 'column', gap: 8, boxShadow: 'var(--shadow-md)' }}>
              <div style={{ fontWeight: 700, fontSize: 12, color: 'var(--text)' }}>Path brush</div>
              <div style={{ height: 54, borderRadius: 8, border: '1px solid var(--border)', background: 'color-mix(in srgb, var(--surface2) 72%, #fff 28%)', display: 'grid', placeItems: 'center', overflow: 'hidden' }}>
                <div style={{ position: 'relative', width: '78%', height: Math.max(3, localPathThickness + Math.max(1, localPathThickness * 0.14)), background: '#6a4b2d' }}>
                  <div style={{ position: 'absolute', left: 0, right: 0, top: '50%', height: localPathThickness, transform: 'translateY(-50%)', background: '#8f7652' }} />
                  <div style={{ position: 'absolute', left: 0, right: 0, top: '50%', height: Math.max(2, localPathThickness * 0.7), transform: 'translateY(-50%)', background: '#d8c095', opacity: 0.78 }} />
                </div>
              </div>
              <label style={{ display: 'grid', gap: 4, fontSize: 11, color: 'var(--muted)', fontWeight: 700 }}>
                Brush size
                <SliderInput min={3} max={128} step={1} value={localPathThickness} onChange={e => setLocalPathThickness(Math.max(3, Number(e.target.value)))} />
              </label>
            </div>
          )}

          {mode === 'opening' && (
            <div style={{ position: 'absolute', left: TOOLBAR_W, top: CMD_H + 8, width: 196, background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 10, padding: 12, zIndex: 20, display: 'flex', flexDirection: 'column', gap: 8, boxShadow: 'var(--shadow-md)' }}>
              <div style={{ fontWeight: 700, fontSize: 12, color: 'var(--text)' }}>Opening</div>
              <div style={{ fontSize: 11, color: 'var(--muted)', lineHeight: 1.4 }}>Choose a type, then click an existing wall.</div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
                {[
                  ['door', 'Door'],
                  ['window', 'Window'],
                ].map(([value, label]) => {
                  const isActive = selectedOpeningKind === value
                  return (
                    <button
                      key={value}
                      type="button"
                      onClick={() => { setSelectedOpeningKind(value); requestRender() }}
                      aria-pressed={isActive}
                      style={{
                        minHeight: 30,
                        borderRadius: 7,
                        border: `2px solid ${isActive ? 'var(--accent)' : 'var(--border)'}`,
                        background: isActive ? 'color-mix(in srgb, var(--accent) 12%, var(--surface2))' : 'var(--surface2)',
                        color: isActive ? 'var(--accent)' : 'var(--text)',
                        cursor: 'pointer',
                        fontFamily: 'inherit',
                        fontSize: 11,
                        fontWeight: isActive ? 700 : 500,
                      }}
                    >
                      {label}
                    </button>
                  )
                })}
              </div>
              {selectedOpeningKind === 'door' && (
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
                  {[
                    ['left-a', 'Left A'],
                    ['left-b', 'Left B'],
                    ['right-a', 'Right A'],
                    ['right-b', 'Right B'],
                  ].map(([value, label]) => {
                    const isActive = selectedDoorSwing === value
                    return (
                      <button
                        key={value}
                        type="button"
                        onClick={() => { setSelectedDoorSwing(value); requestRender() }}
                        aria-pressed={isActive}
                        style={{
                          minHeight: 30,
                          borderRadius: 7,
                          border: `2px solid ${isActive ? 'var(--accent)' : 'var(--border)'}`,
                          background: isActive ? 'color-mix(in srgb, var(--accent) 12%, var(--surface2))' : 'var(--surface2)',
                          color: isActive ? 'var(--accent)' : 'var(--text)',
                          cursor: 'pointer',
                          fontFamily: 'inherit',
                          fontSize: 11,
                          fontWeight: isActive ? 700 : 500,
                        }}
                      >
                        {label}
                      </button>
                    )
                  })}
                </div>
              )}
            </div>
          )}

          {/* Stamp picker */}
          {mode === 'stamp' && (
            <div style={{ position: 'absolute', left: TOOLBAR_W, top: CMD_H + 8, width: 236, maxWidth: 'calc(100vw - 112px)', boxSizing: 'border-box', background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 10, padding: 12, zIndex: 20, display: 'flex', flexDirection: 'column', gap: 8, boxShadow: 'var(--shadow-md)', maxHeight: '80vh', overflow: 'hidden' }}>
              <div style={{ fontWeight: 700, fontSize: 12, color: 'var(--text)' }}>Stamps</div>
              <input value={stampSearch} onChange={e => setStampSearch(e.target.value)} placeholder="Search stamps" style={{ ...inputStyle, width: '100%', minWidth: 0, boxSizing: 'border-box', fontSize: 16, padding: '5px 8px' }} />
              <select value={stampCategory} onChange={e => setStampCategory(e.target.value)} style={{ ...inputStyle, width: '100%', minWidth: 0, boxSizing: 'border-box', fontSize: 16, padding: '5px 8px' }}>
                {allStampCategories.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(58px, 1fr))', gap: 5, overflowX: 'hidden', overflowY: 'auto', flex: 1, minWidth: 0 }}>
                {filteredStamps.map(stamp => (
                  <button
                    key={stamp.id}
                    onClick={() => setSelectedStampId(stamp.id)}
                    title={stamp.name}
                    style={{
                      minHeight: 92,
                      minWidth: 0,
                      padding: '6px 4px', borderRadius: 7, border: `2px solid ${effectiveSelectedStampId === stamp.id ? 'var(--accent)' : 'var(--border)'}`,
                      background: effectiveSelectedStampId === stamp.id ? 'color-mix(in srgb, var(--accent) 14%, var(--surface2))' : 'var(--surface2)',
                      cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 5,
                      fontFamily: 'inherit',
                    }}
                  >
                    <StampPreviewCanvas stamp={stamp} stylePreset={stylePreset} active={effectiveSelectedStampId === stamp.id} />
                    <span style={{ fontSize: 10, lineHeight: 1.15, color: 'var(--muted)', textAlign: 'center', whiteSpace: 'normal', overflowWrap: 'anywhere', width: '100%' }}>{stamp.name}</span>
                  </button>
                ))}
              </div>
              <div style={{ display: 'flex', gap: 5 }}>
                <button className="btn btn-secondary btn-sm" style={{ flex: 1, fontSize: 11 }}
                  onClick={() => setFavoriteStamps(prev => {
                    const next = prev.includes(effectiveSelectedStampId) ? prev.filter(id => id !== effectiveSelectedStampId) : [...prev, effectiveSelectedStampId]
                    saveJson('yow_map_fav_stamps', next); return next
                  })}
                >{favoriteStamps.includes(effectiveSelectedStampId) ? '★ Unfave' : '☆ Favourite'}</button>
              </div>
            </div>
          )}
        </div>

        {/* Canvas */}
        <main
          ref={viewportRef}
          style={{ flex: 1, position: 'relative', overflow: 'hidden', cursor: canvasCursor }}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
          onDoubleClick={handleDoubleClick}
          onPointerLeave={handlePointerLeave}
        >
          <canvas ref={canvasRef} style={{ display: 'block', width: '100%', height: '100%' }} />

          {/* View mode tooltip */}
          {editorMode === 'view' && viewTooltip && (
            <ViewTooltip
              object={viewTooltip.object}
              x={viewTooltip.x}
              y={viewTooltip.y}
              locations={project.locations || []}
            />
          )}

          {/* View mode hint */}
          {editorMode === 'view' && (
            <div style={{ position: 'absolute', top: 12, left: '50%', transform: 'translateX(-50%)', background: 'rgba(0,0,0,0.6)', color: 'rgba(255,255,255,0.75)', borderRadius: 8, padding: '5px 14px', fontSize: 11, backdropFilter: 'blur(4px)', pointerEvents: 'none', whiteSpace: 'nowrap' }}>
              {isInteriorMap ? 'View and pan this interior map' : 'Hover linked locations to preview · Click to open entry'}
            </div>
          )}

          {/* Status pill */}
          <div style={{ position: 'absolute', bottom: 12, left: 12, display: 'flex', gap: 8, background: 'rgba(0,0,0,0.55)', borderRadius: 8, padding: '4px 10px', fontSize: 11, color: 'rgba(255,255,255,0.7)', backdropFilter: 'blur(4px)', pointerEvents: 'none' }}>
            <span>{MAP_W} × {MAP_H}</span>
            <span>{objects.length} objects</span>
            {selectedIds.length > 0 && <span>{selectedIds.length} selected</span>}
          </div>

          {/* Draft hint */}
          {draft && (
            <div style={{ position: 'absolute', bottom: 12, left: '50%', transform: 'translateX(-50%)', background: 'rgba(0,0,0,0.68)', color: '#fff', borderRadius: 8, padding: '6px 14px', fontSize: 12, display: 'flex', gap: 12, backdropFilter: 'blur(4px)' }}>
              <span>{draft.points.length} points</span>
              <span>Enter or double-click to finish</span>
              <button onClick={() => completeDraft()} style={{ background: 'none', border: 'none', color: 'var(--accent)', cursor: 'pointer', padding: 0, fontFamily: 'inherit', fontSize: 12 }}>Done</button>
              <button onClick={() => setDraft(null)} style={{ background: 'none', border: 'none', color: 'rgba(255,255,255,0.5)', cursor: 'pointer', padding: 0, fontFamily: 'inherit', fontSize: 12 }}>Cancel</button>
            </div>
          )}
        </main>

        {/* Right inspector — hidden in view mode */}
        <aside style={{ width: editorMode === 'view' ? 0 : PANEL_W, overflow: 'hidden', background: 'var(--surface)', borderLeft: editorMode === 'view' ? 'none' : '1px solid var(--border)', display: 'flex', flexDirection: 'column', flexShrink: 0, overflowY: editorMode === 'view' ? 'hidden' : 'auto', zIndex: 5, transition: 'width 0.15s' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 3, padding: 8, borderBottom: '1px solid var(--border)' }}>
            <button onClick={() => setInspectorTab('object')} style={tabStyle(inspectorTab === 'object')}>Object</button>
            <button onClick={() => setInspectorTab('layers')} style={tabStyle(inspectorTab === 'layers')}>Layers</button>
            <button onClick={() => setInspectorTab('places')} style={tabStyle(inspectorTab === 'places')}>{isInteriorMap ? 'Rooms' : 'Places'}</button>
            <button onClick={() => setInspectorTab('map')} style={tabStyle(inspectorTab === 'map')}>Map</button>
          </div>

          <div style={{ flex: 1, padding: '12px 14px', display: 'flex', flexDirection: 'column', gap: 10, overflowY: 'auto' }}>
            {inspectorTab === 'object' ? (
              <ObjectInspector
                primarySelection={primarySelection}
                selectedIds={selectedIds}
                selectedSegment={selectedSegment}
                patchSelected={patchSelected}
                deleteSelected={deleteSelected}
                duplicateSelected={duplicateSelected}
                geometryEditMode={geometryEditMode}
                setGeometryEditMode={setGeometryEditMode}
                project={project}
                isCampaign={isCampaign}
                isInteriorMap={isInteriorMap}
                locations={project.locations || []}
                setSelectedLocationId={setSelectedLocationId}
              />
            ) : inspectorTab === 'layers' ? (
              <LayersPanel
                objects={objects}
                layers={schema.layers}
                selectedIds={selectedIds}
                setSelectedIds={setSelectedIds}
                updateObjects={updateObjects}
                persistLayers={persistLayers}
                setMode={setMode}
                territoryNoun={territoryNoun}
              />
            ) : inspectorTab === 'places' ? (
              <PlacesPanel
                objects={objects}
                selectedIds={selectedIds}
                setSelectedIds={setSelectedIds}
                setMode={setMode}
                setInspectorTab={setInspectorTab}
                project={project}
                isInteriorMap={isInteriorMap}
                setSelectedLocationId={setSelectedLocationId}
                territoryNoun={territoryNoun}
                territoryNounPlural={territoryNounPlural}
              />
            ) : (
              <MapInspector
                activeMap={activeMap}
                project={project}
                stylePreset={stylePreset}
                gridSettings={gridSettings}
                baseLayer={baseLayer}
                persistMeta={persistMeta}
                selectMap={selectMap}
                deleteMap={deleteMap}
                renameMap={renameMap}
                onOpenNewMap={() => setShowNewMapModal(true)}
              />
            )}
          </div>
        </aside>
      </div>

      {/* Modals */}
      {modal && (
        <MapModal
          modal={modal}
          onClose={() => { setModal(null); setMode('select') }}
          locConfig={locConfig} setLocConfig={setLocConfig}
          labelConfig={labelConfig} setLabelConfig={setLabelConfig}
          noteConfig={noteConfig} setNoteConfig={setNoteConfig}
          territoryConfig={territoryConfig} setTerritoryConfig={setTerritoryConfig}
          locations={project.locations || []}
          isCampaign={isCampaign}
          isInteriorMap={isInteriorMap}
          isLocalMap={isLocalMap}
          territoryNoun={territoryNoun}
          onConfirm={() => {
            if (modal.kind === 'location' && modal.point) { placeLocationAt(modal.point, locConfig); setModal(null); setMode('select') }
            if (modal.kind === 'label' && modal.point && labelConfig.text.trim()) { placeLabelAt(modal.point, labelConfig); setModal(null); setMode('select') }
            if (modal.kind === 'note' && modal.point) { placeNoteAt(modal.point, noteConfig); setModal(null); setMode('select') }
            if (modal.kind === 'territory' && modal.objectId) {
              const name = (territoryConfig.name || '').trim()
              let locationId = isInteriorMap ? null : (territoryConfig.linkToId || null)
              if (!isInteriorMap && territoryConfig.createNewLocation && name && saveLocation) {
                const loc = saveLocation({ name, category: territoryNoun, description: '' })
                if (loc?.id) locationId = loc.id
              }
              const ids = new Set([modal.objectId])
              updateObjects(cur => cur.map(o => ids.has(o.id)
                ? { ...o, properties: { ...o.properties, name, fill: territoryConfig.fill || o.properties.fill }, linkedEntity: locationId ? { entityType: 'location', entityId: locationId } : null }
                : o))
              setTerritoryConfig({ name: '', fill: '#7050a8', linkToId: '', createNewLocation: false })
              setModal(null); setMode('select')
            }
          }}
        />
      )}
      {showNewMapModal && (
        <NewMapModal
          onClose={() => setShowNewMapModal(false)}
          onCreate={handleCreateMap}
        />
      )}
    </div>
  )
}

// ─── Object Inspector ─────────────────────────────────────────────────────────

function SliderInput({ value, min, max, step = 1, onChange, numWidth = 54 }) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: `1fr ${numWidth}px`, gap: 8, alignItems: 'center' }}>
      <input type="range" min={min} max={max} step={step} value={value} onChange={onChange} style={{ width: '100%' }} />
      <input type="number" min={min} max={max} step={step} value={value} onChange={onChange} style={{ ...inputStyle, padding: '5px 6px', fontSize: 16 }} />
    </div>
  )
}

function TransparentColorInput({ value, fallback, onChange, noneLabel = 'None' }) {
  const isTransparent = value === 'transparent'
  return (
    <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
      <input
        type="color"
        value={isTransparent ? fallback : (value || fallback)}
        onChange={e => onChange(e.target.value)}
        disabled={isTransparent}
        style={{ ...inputStyle, height: 32, padding: 2, flex: 1, opacity: isTransparent ? 0.4 : 1 }}
      />
      <label title="Transparent" style={{ cursor: 'pointer', fontSize: 10, color: 'var(--muted)', whiteSpace: 'nowrap' }}>
        <input
          type="checkbox"
          checked={isTransparent}
          onChange={e => onChange(e.target.checked ? 'transparent' : fallback)}
          style={{ marginRight: 3 }}
        />
        {noneLabel}
      </label>
    </div>
  )
}

function ObjectInspector({ primarySelection, selectedIds, patchSelected, deleteSelected, duplicateSelected, geometryEditMode, setGeometryEditMode, project, isCampaign, isInteriorMap, locations, setSelectedLocationId }) {
  if (!primarySelection) {
    return <div style={{ color: 'var(--muted)', fontSize: 13, lineHeight: 1.5 }}>Select an object on the canvas to edit its properties.</div>
  }

  const o = primarySelection
  const multi = selectedIds.length > 1

  function prop(key) { return o.properties?.[key] }
  function setProp(key, val) { patchSelected({ properties: { [key]: val } }) }

  const linkedLocation = o.linkedEntity?.entityType === 'location'
    ? (project.locations || []).find(l => l.id === o.linkedEntity.entityId) : null

  return (
    <>
      {multi && <div style={{ fontSize: 11, color: 'var(--muted)', padding: '4px 8px', background: 'var(--surface2)', borderRadius: 6 }}>{selectedIds.length} objects selected — changes apply to all</div>}

      <Field label="Name">
        <input value={prop('name') || ''} onChange={e => setProp('name', e.target.value)} style={inputStyle} />
      </Field>

      {o.geometry?.points?.length > 0 && (
        <Field label="Edit mode">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
            {[
              ['points', 'Points'],
              ['resize', 'Resize'],
            ].map(([value, label]) => {
              const isActive = geometryEditMode === value
              return (
                <button
                  key={value}
                  type="button"
                  onClick={() => setGeometryEditMode(value)}
                  aria-pressed={isActive}
                  style={{
                    minHeight: 30,
                    borderRadius: 7,
                    border: `2px solid ${isActive ? 'var(--accent)' : 'var(--border)'}`,
                    background: isActive ? 'color-mix(in srgb, var(--accent) 12%, var(--surface2))' : 'var(--surface2)',
                    color: isActive ? 'var(--accent)' : 'var(--text)',
                    cursor: 'pointer',
                    fontFamily: 'inherit',
                    fontSize: 11,
                    fontWeight: isActive ? 700 : 500,
                  }}
                >
                  {label}
                </button>
              )
            })}
          </div>
        </Field>
      )}

      {/* Worldbuilding integration — most prominent for location/stamp/region */}
      {!isInteriorMap && (o.type === 'location' || o.type === 'territory' || (o.type === 'stamp' && ['capital', 'city', 'village', 'castle', 'fortress', 'harbor'].includes(prop('stampId')))) && (
        <div style={{ border: '1px solid var(--border)', borderRadius: 8, padding: '10px 12px', display: 'flex', flexDirection: 'column', gap: 7, background: 'color-mix(in srgb, var(--accent) 7%, var(--surface))' }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--accent)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>Worldbuilding link</div>
          {linkedLocation ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              <div style={{ fontWeight: 600, fontSize: 13, color: 'var(--text)' }}>→ {linkedLocation.name}</div>
              <div style={{ fontSize: 11, color: 'var(--muted)' }}>Location · {linkedLocation.category || 'Other'}</div>
              <div style={{ display: 'flex', gap: 6 }}>
                <button className="btn btn-primary btn-sm" style={{ fontSize: 11 }} onClick={() => { setSelectedLocationId?.(linkedLocation.id); window.dispatchEvent(new CustomEvent('switch-section', { detail: { section: 'locations' } })) }}>Open location</button>
                <button className="btn btn-secondary btn-sm" style={{ fontSize: 11 }} onClick={() => patchSelected({ linkedEntity: null })}>Unlink</button>
              </div>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              <div style={{ fontSize: 12, color: 'var(--muted)' }}>Not linked to a worldbuilding entry.</div>
              <Field label="Link to existing location">
                <select
                  value={o.linkedEntity?.entityId || ''}
                  onChange={e => {
                    const loc = locations.find(l => l.id === e.target.value)
                    patchSelected({ properties: { name: loc?.name || prop('name') }, linkedEntity: loc ? { entityType: 'location', entityId: loc.id } : null })
                  }}
                  style={inputStyle}
                >
                  <option value="">— unlinked —</option>
                  {locations.map(l => <option key={l.id} value={l.id}>{l.name}</option>)}
                </select>
              </Field>
            </div>
          )}
        </div>
      )}

      {/* Type-specific fields */}
      {o.type === 'location' && (
        <>
          <Field label="Marker icon">
            <select value={prop('markerIcon') || 'pin'} onChange={e => setProp('markerIcon', e.target.value)} style={inputStyle}>
              {LOCATION_ICON_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
          </Field>
          <Field label="Icon size">
            <SliderInput min={8} max={240} step={1} value={prop('iconSize') || o.width || DEFAULT_LOCATION_ICON_SIZE} onChange={e => setProp('iconSize', clamp(Number(e.target.value) || DEFAULT_LOCATION_ICON_SIZE, 8, 240))} />
          </Field>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
            <Field label="Icon colour">
              <input type="color" value={prop('fill') || DEFAULT_LOCATION_FILL} onChange={e => setProp('fill', e.target.value)} style={{ ...inputStyle, height: 32, padding: 2 }} />
            </Field>
            <Field label="Icon outline">
              <TransparentColorInput value={prop('stroke')} fallback={DEFAULT_LOCATION_STROKE} onChange={value => setProp('stroke', value)} />
            </Field>
          </div>
          <Field label="Label size">
            <SliderInput min={8} max={96} step={1} value={prop('labelFontSize') || Math.max(DEFAULT_LOCATION_LABEL_SIZE, round((o.width || 64) * 0.19, 0))} onChange={e => setProp('labelFontSize', clamp(Number(e.target.value) || DEFAULT_LOCATION_LABEL_SIZE, 8, 96))} />
          </Field>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
            <Field label="Label colour">
              <input type="color" value={prop('labelColor') || DEFAULT_LOCATION_LABEL_COLOR} onChange={e => setProp('labelColor', e.target.value)} style={{ ...inputStyle, height: 32, padding: 2 }} />
            </Field>
            <Field label="Label outline">
              <TransparentColorInput value={prop('labelOutlineColor')} fallback={DEFAULT_LOCATION_LABEL_OUTLINE} onChange={value => setProp('labelOutlineColor', value)} />
            </Field>
          </div>
        </>
      )}

      {o.type === 'region' && (
        <div style={{ border: '1px solid var(--border)', borderRadius: 8, padding: '10px 12px', display: 'flex', flexDirection: 'column', gap: 8 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Terrain type</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 5 }}>
            {TERRAIN_TYPES.map(t => {
              const isActive = (prop('terrainType') || 'grassland') === t.value
              return (
                <button
                  key={t.value}
                  onClick={() => patchSelected({ properties: { terrainType: t.value, fill: t.color } })}
                  style={{
                    display: 'flex', alignItems: 'center', gap: 6, padding: '5px 7px',
                    borderRadius: 6, border: `2px solid ${isActive ? 'var(--accent)' : 'var(--border)'}`,
                    background: isActive ? 'color-mix(in srgb, var(--accent) 12%, var(--surface2))' : 'var(--surface2)',
                    cursor: 'pointer', fontFamily: 'inherit',
                  }}
                >
                  <span style={{ width: 12, height: 12, borderRadius: 3, background: t.color, flexShrink: 0, border: '1px solid rgba(0,0,0,0.2)' }} />
                  <span style={{ fontSize: 10, fontWeight: isActive ? 700 : 400, color: isActive ? 'var(--accent)' : 'var(--text)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{t.label}</span>
                </button>
              )
            })}
          </div>
          <Field label="Symbol size">
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 46px', gap: 8, alignItems: 'center' }}>
              <input
                type="range"
                min="55"
                max="180"
                step="5"
                value={round((prop('terrainSymbolScale') || 1) * 100, 0)}
                onChange={e => setProp('terrainSymbolScale', clamp(Number(e.target.value) / 100, 0.55, 1.8))}
                style={{ width: '100%' }}
              />
              <input
                type="number"
                min="55"
                max="180"
                step="5"
                value={round((prop('terrainSymbolScale') || 1) * 100, 0)}
                onChange={e => setProp('terrainSymbolScale', clamp(Number(e.target.value) / 100, 0.55, 1.8))}
                style={{ ...inputStyle, padding: '5px 6px', fontSize: 16 }}
              />
            </div>
          </Field>
        </div>
      )}

      {(o.type === 'shape' || o.type === 'region') && (
        <Field label="Organic edges">
          <input type="checkbox" checked={prop('organicEdges') !== false} onChange={e => setProp('organicEdges', e.target.checked)} />
        </Field>
      )}

      {o.type === 'label' && (
        <>
          <Field label="Text">
            <input value={prop('text') || prop('name') || ''} onChange={e => patchSelected({ properties: { text: e.target.value, name: e.target.value } })} style={inputStyle} />
          </Field>
          <Field label="Font">
            <select value={prop('fontFamily') || MAP_FONT_OPTIONS[0].value} onChange={e => setProp('fontFamily', e.target.value)} style={inputStyle}>
              {MAP_FONT_OPTIONS.map(f => <option key={f.value} value={f.value}>{f.label}</option>)}
            </select>
          </Field>
          <Field label="Size"><SliderInput min={10} max={200} step={1} value={prop('fontSize') || 40} onChange={e => setProp('fontSize', Math.max(10, Number(e.target.value)))} /></Field>
          <Field label="Style">
            <select value={prop('fontStyle') || 'normal'} onChange={e => setProp('fontStyle', e.target.value)} style={inputStyle}>
              <option value="normal">Regular</option><option value="italic">Italic</option>
            </select>
          </Field>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
            <Field label="Text colour"><input type="color" value={prop('textColor') === 'transparent' ? '#1a140a' : (prop('textColor') || '#1a140a')} onChange={e => setProp('textColor', e.target.value)} style={{ ...inputStyle, height: 32, padding: 2 }} /></Field>
            <Field label="Outline colour">
              <TransparentColorInput value={prop('outlineColor')} fallback="#f4e8c4" onChange={value => setProp('outlineColor', value)} />
            </Field>
          </div>
        </>
      )}

      {o.type === 'note' && (
        <>
          <Field label="Title">
            <input value={prop('title') || ''} onChange={e => patchSelected({ properties: { title: e.target.value, name: e.target.value || 'Note' } })} style={inputStyle} />
          </Field>
          <label style={checkStyle}>
            <input type="checkbox" disabled={Boolean(prop('gmOnly'))} checked={prop('visibility') === 'public' && !prop('gmOnly')} onChange={e => setProp('visibility', e.target.checked ? 'public' : 'private')} /> Include title marker in PNG exports
          </label>
          {isCampaign && <label style={{ display: 'flex', gap: 8, alignItems: 'center', fontSize: 12, color: 'var(--text)', cursor: 'pointer' }}><input type="checkbox" checked={Boolean(prop('gmOnly'))} onChange={e => patchSelected({ properties: { gmOnly: e.target.checked, ...(e.target.checked ? { visibility: 'private' } : {}) } })} /> GM only</label>}
        </>
      )}

      {/* Fill/stroke for polygon shapes */}
      {(o.type === 'shape' || o.type === 'region') && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
          <Field label="Fill"><input type="color" value={prop('fill') || '#1e3d20'} onChange={e => setProp('fill', e.target.value)} style={{ ...inputStyle, height: 32, padding: 2 }} /></Field>
          <Field label="Outline">
            <TransparentColorInput value={prop('stroke')} fallback="#142a16" onChange={value => setProp('stroke', value)} />
          </Field>
        </div>
      )}

      {/* Territory fill + label controls */}
      {o.type === 'territory' && (
        <>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
            <Field label="Fill"><input type="color" value={prop('fill') || '#7050a8'} onChange={e => setProp('fill', e.target.value)} style={{ ...inputStyle, height: 32, padding: 2 }} /></Field>
            <Field label="Outline">
              <TransparentColorInput value={prop('stroke')} fallback="#4a3070" onChange={value => setProp('stroke', value)} />
            </Field>
          </div>
          <Field label="Fill opacity %">
            <SliderInput
              min={0}
              max={100}
              step={1}
              value={round((Number.isFinite(prop('fillOpacity')) ? prop('fillOpacity') : 1) * 100, 0)}
              onChange={e => setProp('fillOpacity', clamp(Number(e.target.value) / 100, 0, 1))}
            />
          </Field>
          {prop('semanticType') === 'room' && (
            <Field label="Room edges">
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
                {[
                  ['straight', 'Straight'],
                  ['curved', 'Curved'],
                ].map(([value, label]) => {
                  const isActive = (prop('lineStyle') || 'straight') === value
                  return (
                    <button
                      key={value}
                      type="button"
                      onClick={() => setProp('lineStyle', value)}
                      aria-pressed={isActive}
                      style={{
                        minHeight: 30,
                        borderRadius: 7,
                        border: `2px solid ${isActive ? 'var(--accent)' : 'var(--border)'}`,
                        background: isActive ? 'color-mix(in srgb, var(--accent) 12%, var(--surface2))' : 'var(--surface2)',
                        color: isActive ? 'var(--accent)' : 'var(--text)',
                        cursor: 'pointer',
                        fontFamily: 'inherit',
                        fontSize: 11,
                        fontWeight: isActive ? 700 : 500,
                      }}
                    >
                      {label}
                    </button>
                  )
                })}
              </div>
            </Field>
          )}
          <Field label="Label">
            <label style={{ display: 'flex', gap: 8, alignItems: 'center', fontSize: 12, color: 'var(--text)', cursor: 'pointer' }}>
              <input type="checkbox" checked={!prop('labelHidden')} onChange={e => setProp('labelHidden', !e.target.checked)} />
              Show label
            </label>
          </Field>
          {!prop('labelHidden') && (
            <>
              <Field label="Label size">
                <SliderInput min={10} max={96} step={1} value={prop('labelFontSize') || 0} onChange={e => setProp('labelFontSize', Number(e.target.value) || 0)} />
              </Field>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
                <Field label="Label colour">
                  <input type="color" value={prop('labelColor') || prop('fill') || '#7050a8'} onChange={e => setProp('labelColor', e.target.value)} style={{ ...inputStyle, height: 32, padding: 2 }} />
                </Field>
                <Field label="Label outline">
                  <TransparentColorInput value={prop('labelOutlineColor')} fallback="#f4e8c4" onChange={value => setProp('labelOutlineColor', value)} />
                </Field>
              </div>
              <Field label="Label offset X">
                <SliderInput min={-600} max={600} step={1} value={prop('labelOffsetX') || 0} onChange={e => setProp('labelOffsetX', Number(e.target.value))} />
              </Field>
              <Field label="Label offset Y">
                <SliderInput min={-400} max={400} step={1} value={prop('labelOffsetY') || 0} onChange={e => setProp('labelOffsetY', Number(e.target.value))} />
              </Field>
              <button
                type="button"
                onClick={() => patchSelected({ properties: { labelOffsetX: 0, labelOffsetY: 0, labelFontSize: 0 } })}
                style={{ ...inputStyle, cursor: 'pointer', fontSize: 11, padding: '5px 10px', width: 'fit-content' }}
              >Reset label position</button>
            </>
          )}
        </>
      )}

      {o.type === 'opening' && (
        <>
          <Field label="Opening type">
            <select value={prop('openingKind') || 'door'} onChange={e => patchSelected({ properties: { openingKind: e.target.value, name: e.target.value === 'window' ? 'Window' : 'Door' } })} style={inputStyle}>
              <option value="door">Door</option>
              <option value="window">Window</option>
            </select>
          </Field>
          {(prop('openingKind') || 'door') === 'door' && (
            <Field label="Door swing">
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
                {[
                  ['left-a', 'Left A'],
                  ['left-b', 'Left B'],
                  ['right-a', 'Right A'],
                  ['right-b', 'Right B'],
                ].map(([value, label]) => {
                  const currentSwing = prop('doorSwing') === -1 ? 'left-b' : (prop('doorSwing') || 'left-a')
                  const isActive = currentSwing === value
                  return (
                    <button
                      key={value}
                      type="button"
                      onClick={() => setProp('doorSwing', value)}
                      aria-pressed={isActive}
                      style={{
                        minHeight: 30,
                        borderRadius: 7,
                        border: `2px solid ${isActive ? 'var(--accent)' : 'var(--border)'}`,
                        background: isActive ? 'color-mix(in srgb, var(--accent) 12%, var(--surface2))' : 'var(--surface2)',
                        color: isActive ? 'var(--accent)' : 'var(--text)',
                        cursor: 'pointer',
                        fontFamily: 'inherit',
                        fontSize: 11,
                        fontWeight: isActive ? 700 : 500,
                      }}
                    >
                      {label}
                    </button>
                  )
                })}
              </div>
            </Field>
          )}
        </>
      )}

      {/* Line objects */}
      {['water', 'river', 'road', 'path', 'border', 'mountain', 'wall'].includes(o.type) && (
        <>
          {o.type === 'water' && o.geometry?.type === 'polygon' && (
            <>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
                <Field label="Fill"><input type="color" value={prop('fill') || '#73b8cf'} onChange={e => setProp('fill', e.target.value)} style={{ ...inputStyle, height: 32, padding: 2 }} /></Field>
                <Field label="Outline">
                  <TransparentColorInput value={prop('stroke')} fallback="#2f769f" onChange={value => setProp('stroke', value)} />
                </Field>
              </div>
              <label style={checkStyle}><input type="checkbox" checked={prop('organicEdges') !== false} onChange={e => setProp('organicEdges', e.target.checked)} /> Organic edge</label>
              <label style={checkStyle}><input type="checkbox" checked={prop('waveTexture') !== false} onChange={e => setProp('waveTexture', e.target.checked)} /> Wave texture</label>
            </>
          )}
          {(o.type !== 'water' || o.geometry?.type !== 'polygon') && o.type !== 'border' && (
            <Field label="Colour"><input type="color" value={prop('stroke') || (o.type === 'river' ? '#2f5f78' : '#333')} onChange={e => setProp('stroke', e.target.value)} style={{ ...inputStyle, height: 32, padding: 2 }} /></Field>
          )}
          {o.type === 'wall' && (
            <>
              {(prop('semanticType') === 'localWall' || isInteriorMap) && (
                <Field label="Material">
                  <select
                    value={prop('wallMaterial') || 'grey-brick'}
                    onChange={e => {
                      const material = getLocalWallMaterial(e.target.value)
                      patchSelected({ properties: { wallMaterial: material.value, stroke: material.stroke, highlight: material.highlight, mortar: material.mortar } })
                    }}
                    style={inputStyle}
                  >
                    {LOCAL_WALL_MATERIALS.map(material => <option key={material.value} value={material.value}>{material.label}</option>)}
                  </select>
                </Field>
              )}
              <Field label="Wall lines">
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
                  {[
                    ['straight', 'Straight'],
                    ['curved', 'Curved'],
                  ].map(([value, label]) => {
                    const isActive = (prop('lineStyle') || 'straight') === value
                    return (
                      <button
                        key={value}
                        type="button"
                        onClick={() => setProp('lineStyle', value)}
                        aria-pressed={isActive}
                        style={{
                          minHeight: 30,
                          borderRadius: 7,
                          border: `2px solid ${isActive ? 'var(--accent)' : 'var(--border)'}`,
                          background: isActive ? 'color-mix(in srgb, var(--accent) 12%, var(--surface2))' : 'var(--surface2)',
                          color: isActive ? 'var(--accent)' : 'var(--text)',
                          cursor: 'pointer',
                          fontFamily: 'inherit',
                          fontSize: 11,
                          fontWeight: isActive ? 700 : 500,
                        }}
                      >
                        {label}
                      </button>
                    )
                  })}
                </div>
              </Field>
              <Field label="Inner mark">
                <TransparentColorInput value={prop('highlight')} fallback="#88aeca" onChange={value => setProp('highlight', value)} />
              </Field>
            </>
          )}
          {o.type === 'border' && (
            <Field label="Border">
              <TransparentColorInput value={prop('stroke')} fallback="#9050a0" onChange={value => setProp('stroke', value)} />
            </Field>
          )}
          {o.type === 'road' && <>
            <Field label="Border">
              <TransparentColorInput value={prop('borderStroke')} fallback="#2c1a0a" onChange={value => setProp('borderStroke', value)} />
            </Field>
            <Field label="Fill"><input type="color" value={prop('highlight') || '#f0d8a0'} onChange={e => setProp('highlight', e.target.value)} style={{ ...inputStyle, height: 32, padding: 2 }} /></Field>
          </>}
          {o.type === 'path' && <>
            <Field label="Border">
              <TransparentColorInput value={prop('borderStroke')} fallback="#6a4b2d" onChange={value => setProp('borderStroke', value)} />
            </Field>
            <Field label="Fill"><input type="color" value={prop('highlight') || '#d8c095'} onChange={e => setProp('highlight', e.target.value)} style={{ ...inputStyle, height: 32, padding: 2 }} /></Field>
          </>}
          <Field label={o.type === 'water' && o.geometry?.type === 'polygon' ? 'Outline' : 'Thickness'}><SliderInput min={1} max={o.type === 'path' ? 128 : o.type === 'wall' ? 64 : 40} step={1} value={prop('lineThickness') || 5} onChange={e => setProp('lineThickness', Math.max(1, Number(e.target.value)))} /></Field>
        </>
      )}

      {/* Opacity */}
      {o.type === 'region' && (
        <>
          <Field label="Transparent bg">
            <input
              type="checkbox"
              checked={Boolean(prop('terrainBackgroundTransparent')) || (prop('terrainFillOpacity') ?? prop('opacity') ?? 0.44) === 0}
              onChange={e => patchSelected({ properties: { terrainBackgroundTransparent: e.target.checked, terrainFillOpacity: e.target.checked ? 0 : 1 } })}
            />
          </Field>
          <Field label="Background %">
            <SliderInput
              min={0} max={100} step={1}
              value={prop('terrainBackgroundTransparent') ? 0 : round((((prop('terrainFillOpacity') ?? prop('opacity') ?? DEFAULT_REGION_FILL_OPACITY) === 0.44 ? 1 : (prop('terrainFillOpacity') ?? prop('opacity') ?? DEFAULT_REGION_FILL_OPACITY)) * 100), 0)}
              onChange={e => patchSelected({ properties: { terrainBackgroundTransparent: Number(e.target.value) <= 0, terrainFillOpacity: clamp(Number(e.target.value) / 100, 0, 1) } })}
            />
          </Field>
        </>
      )}
      {/* Notes (private, for all objects) */}
      <Field label="Notes (private)">
        <textarea
          value={prop('notes') || ''}
          onChange={e => setProp('notes', e.target.value)}
          placeholder="Private notes for this object..."
          rows={3}
          style={{ ...inputStyle, resize: 'vertical', minHeight: 64 }}
        />
      </Field>
      {isCampaign && o.type !== 'note' && (
        <label style={{ display: 'flex', gap: 8, alignItems: 'center', fontSize: 12, color: 'var(--text)', cursor: 'pointer' }}>
          <input type="checkbox" checked={Boolean(prop('gmOnly'))} onChange={e => setProp('gmOnly', e.target.checked)} /> GM only
        </label>
      )}

      {o.type === 'stamp' && !o.geometry && (
        <>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 6 }}>
            <Field label="Fill / tint">
              <input
                type="color"
                value={prop('stampFill') || '#1a140a'}
                onChange={e => setProp('stampFill', e.target.value)}
                style={{ ...inputStyle, height: 32, padding: 3 }}
              />
            </Field>
            <Field label="Outline">
              <input
                type="color"
                value={prop('stampStroke') || '#1a140a'}
                onChange={e => setProp('stampStroke', e.target.value)}
                style={{ ...inputStyle, height: 32, padding: 3 }}
              />
            </Field>
            <Field label="Accent">
              <input
                type="color"
                value={prop('stampHighlight') || '#f4ecd4'}
                onChange={e => setProp('stampHighlight', e.target.value)}
                style={{ ...inputStyle, height: 32, padding: 3 }}
              />
            </Field>
          </div>
          <Field label="Stamp size">
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 54px', gap: 8, alignItems: 'center' }}>
              <input
                type="range"
                min={MIN_SIZE}
                max="320"
                step="2"
                value={round(o.width || o.height || 80, 0)}
                onChange={e => {
                  const size = clamp(Number(e.target.value) || 80, MIN_SIZE, 320)
                  patchSelected({ width: size, height: size })
                }}
                style={{ width: '100%' }}
              />
              <input
                type="number"
                min={MIN_SIZE}
                max="320"
                value={round(o.width || o.height || 80, 0)}
                onChange={e => {
                  const size = clamp(Number(e.target.value) || 80, MIN_SIZE, 320)
                  patchSelected({ width: size, height: size })
                }}
                style={{ ...inputStyle, padding: '5px 6px', fontSize: 16 }}
              />
            </div>
          </Field>
        </>
      )}

      {/* Position/size for point objects */}
      {!o.geometry && (
        <>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
            <Field label="X"><input type="number" value={round(o.x || 0, 0)} onChange={e => patchSelected({ x: Number(e.target.value) })} style={inputStyle} /></Field>
            <Field label="Y"><input type="number" value={round(o.y || 0, 0)} onChange={e => patchSelected({ y: Number(e.target.value) })} style={inputStyle} /></Field>
            <Field label="Rotate"><input type="number" value={round(o.rotation || 0, 0)} onChange={e => patchSelected({ rotation: Number(e.target.value) })} style={inputStyle} /></Field>
          </div>
          {o.type !== 'stamp' && (
            <>
              <Field label="Width"><SliderInput min={MIN_SIZE} max={800} step={1} value={round(o.width || 80, 0)} onChange={e => patchSelected({ width: Math.max(MIN_SIZE, Number(e.target.value)) })} /></Field>
              <Field label="Height"><SliderInput min={MIN_SIZE} max={800} step={1} value={round(o.height || 80, 0)} onChange={e => patchSelected({ height: Math.max(MIN_SIZE, Number(e.target.value)) })} /></Field>
            </>
          )}
        </>
      )}

      {/* Actions */}
      <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap', marginTop: 4 }}>
        <button className="btn btn-secondary btn-sm" style={{ fontSize: 11 }} onClick={duplicateSelected}>Duplicate</button>
        <button className="btn btn-secondary btn-sm" style={{ fontSize: 11 }} onClick={() => patchSelected({ locked: !o.locked })}>{o.locked ? 'Unlock' : 'Lock'}</button>
        <button className="btn btn-secondary btn-sm" style={{ fontSize: 11 }} onClick={() => patchSelected({ visible: o.visible === false })}>{o.visible === false ? 'Show' : 'Hide'}</button>
        <button className="btn btn-secondary btn-sm" style={{ fontSize: 11, color: 'var(--danger)' }} onClick={deleteSelected}>Delete</button>
      </div>
    </>
  )
}

// ─── Layers Panel ─────────────────────────────────────────────────────────────

const TYPE_ICONS = { shape: '▰', region: '◫', territory: '□', wall: '▊', opening: '⌞', water: '≈', river: '〜', road: '—', path: '╌', border: '⋯', mountain: '△', stamp: '✦', location: '⌖', label: 'T', note: '✎', marker: '•' }
const TYPE_COLORS = { shape: '#3a7a3a', region: '#6a9a44', territory: '#7050a8', wall: '#6f8796', opening: '#9fb7c5', water: '#2f769f', river: '#2f5f78', road: '#8b6030', path: '#9a7448', border: '#9050a0', mountain: '#7a7060', stamp: '#8f6a33', location: '#c8602a', label: '#2a6090', note: '#c8a020' }
const TYPE_LABELS = { shape: 'Landmass', region: 'Terrain', territory: 'Region', wall: 'Wall', opening: 'Door / Window', water: 'Water', river: 'River', road: 'Road', path: 'Path', border: 'Border', mountain: 'Mountain ridge', stamp: 'Stamp', location: 'Location', label: 'Label', note: 'Note', marker: 'Marker' }

function LayersPanel({ objects, layers, selectedIds, setSelectedIds, updateObjects, persistLayers, setMode, territoryNoun = 'Region' }) {
  const [draggingId, setDraggingId] = useState(null) // object id or 'group:groupId'
  const [dropTarget, setDropTarget] = useState(null) // { id, position: 'before'|'after'|'into', isGroup }
  const [renamingGroupId, setRenamingGroupId] = useState(null)
  const [renameVal, setRenameVal] = useState('')
  const [collapsedGroups, setCollapsedGroups] = useState({})
  const [filterSelectedType, setFilterSelectedType] = useState(false)

  const groups = layers || []
  const sorted = [...objects].sort((a, b) => (b.zIndex || 0) - (a.zIndex || 0))
  const selectedType = objects.find(o => selectedIds.includes(o.id))?.type || ''
  const selectedTypeLabel = selectedType ? (selectedType === 'territory' ? territoryNoun : TYPE_LABELS[selectedType] || selectedType) : ''
  const typeFiltered = Boolean(filterSelectedType && selectedType)
  const displayedSorted = typeFiltered ? sorted.filter(o => o.type === selectedType) : sorted
  const ungrouped = displayedSorted.filter(o => !o.groupId)
  const groupedMap = {}
  groups.forEach(g => { groupedMap[g.id] = displayedSorted.filter(o => o.groupId === g.id) })
  const visibleGroups = typeFiltered ? groups.filter(g => groupedMap[g.id]?.length) : groups

  function moveObjectInList(id, direction) {
    const allSorted = buildFlatList()
    const idx = allSorted.findIndex(item => item.type === 'object' && item.id === id)
    const targetIdx = clamp(idx + direction, 0, allSorted.filter(i => i.type === 'object').length - 1)
    if (idx < 0 || targetIdx === idx) return
    const objectsOnly = allSorted.filter(i => i.type === 'object')
    const objIdx = objectsOnly.findIndex(i => i.id === id)
    const newObjIdx = clamp(objIdx + direction, 0, objectsOnly.length - 1)
    const next = [...objectsOnly]
    const [item] = next.splice(objIdx, 1)
    next.splice(newObjIdx, 0, item)
    const count = next.length
    const zById = new Map(next.map((o, index) => [o.id, count - index]))
    updateObjects(cur => cur.map(o => zById.has(o.id) ? { ...o, zIndex: zById.get(o.id) } : o))
  }

  function buildFlatList() {
    const items = []
    visibleGroups.forEach(g => {
      items.push({ type: 'group', id: g.id })
      if (!collapsedGroups[g.id]) {
        groupedMap[g.id]?.forEach(o => items.push({ type: 'object', id: o.id, groupId: g.id }))
      }
    })
    ungrouped.forEach(o => items.push({ type: 'object', id: o.id, groupId: null }))
    return items
  }

  function handleObjectDrop(targetId, targetGroupId, position) {
    if (!draggingId || draggingId.startsWith('group:')) return
    if (draggingId === targetId) { setDraggingId(null); setDropTarget(null); return }

    const draggingObj = objects.find(o => o.id === draggingId)
    if (!draggingObj) return

    const sourceIdx = sorted.findIndex(o => o.id === draggingId)
    const targetIdx = sorted.findIndex(o => o.id === targetId)
    if (sourceIdx < 0 || targetIdx < 0) return

    const next = [...sorted]
    const [item] = next.splice(sourceIdx, 1)
    const newTargetIdx = next.findIndex(o => o.id === targetId)
    next.splice(position === 'after' ? newTargetIdx + 1 : newTargetIdx, 0, item)

    const count = next.length
    const zById = new Map(next.map((o, index) => [o.id, count - index]))
    updateObjects(cur => cur.map(o => {
      if (!zById.has(o.id)) return o
      if (o.id === draggingId) return { ...o, zIndex: zById.get(o.id), groupId: targetGroupId || null }
      return { ...o, zIndex: zById.get(o.id) }
    }))
    setDraggingId(null); setDropTarget(null)
  }

  function handleDropIntoGroup(groupId) {
    if (!draggingId || draggingId.startsWith('group:')) return
    updateObjects(cur => cur.map(o => o.id === draggingId ? { ...o, groupId } : o))
    setDraggingId(null); setDropTarget(null)
  }

  function handleGroupDrop(targetGroupId, position) {
    if (!draggingId?.startsWith('group:')) return
    const srcId = draggingId.replace('group:', '')
    if (srcId === targetGroupId) { setDraggingId(null); setDropTarget(null); return }
    const srcIdx = groups.findIndex(g => g.id === srcId)
    const tgtIdx = groups.findIndex(g => g.id === targetGroupId)
    if (srcIdx < 0 || tgtIdx < 0) return
    const next = [...groups]
    const [item] = next.splice(srcIdx, 1)
    const newTgt = next.findIndex(g => g.id === targetGroupId)
    next.splice(position === 'after' ? newTgt + 1 : newTgt, 0, item)
    persistLayers(next)
    setDraggingId(null); setDropTarget(null)
  }

  function toggleVisible(id) {
    updateObjects(cur => cur.map(o => o.id === id ? { ...o, visible: o.visible === false } : o))
  }

  function toggleGroupVisible(groupId) {
    const g = groups.find(x => x.id === groupId)
    if (!g) return
    const nextLayers = groups.map(x => x.id === groupId ? { ...x, visible: x.visible === false } : x)
    // Keep group metadata and its object visibility in one map update. Separate
    // writes race through React state and can restore stale layers or objects.
    updateObjects(
      cur => cur.map(o => o.groupId === groupId ? { ...o, visible: g.visible === false ? undefined : false } : o),
      { nextLayers },
    )
  }

  function deleteOne(id) {
    updateObjects(cur => cur.filter(o => o.id !== id))
    setSelectedIds(prev => prev.filter(sid => sid !== id))
  }

  function deleteGroup(groupId) {
    // Ungroup objects (remove groupId), then delete group
    updateObjects(
      cur => cur.map(o => o.groupId === groupId ? { ...o, groupId: null } : o),
      { nextLayers: groups.filter(g => g.id !== groupId) },
    )
  }

  function createGroup() {
    const newGroup = { id: uid('grp'), name: 'New Group', visible: true }
    persistLayers([...groups, newGroup])
    setTimeout(() => { setRenamingGroupId(newGroup.id); setRenameVal('New Group') }, 50)
  }

  function saveGroupRename() {
    if (!renamingGroupId) return
    const trimmed = renameVal.trim()
    if (trimmed) persistLayers(groups.map(g => g.id === renamingGroupId ? { ...g, name: trimmed } : g))
    setRenamingGroupId(null)
  }

  function removeFromGroup(id) {
    updateObjects(cur => cur.map(o => o.id === id ? { ...o, groupId: null } : o))
  }

  function DropLine({ show }) {
    if (!show) return null
    return <div style={{ height: 2, background: 'var(--accent)', borderRadius: 2, margin: '0 4px', flexShrink: 0 }} />
  }

  if (!objects.length) {
    return <div style={{ color: 'var(--muted)', fontSize: 13, lineHeight: 1.5 }}>No objects yet. Draw on the canvas to add objects.</div>
  }

  return (
    <>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ fontSize: 11, color: 'var(--muted)', fontWeight: 600 }}>{typeFiltered ? `${displayedSorted.length} of ${objects.length}` : objects.length} objects</div>
        <button onClick={createGroup} title="New group" style={{ ...layerBtnStyle, fontSize: 11, padding: '2px 7px', border: '1px solid var(--border)', borderRadius: 5, background: 'var(--surface2)' }}>+ Group</button>
      </div>

      <button
        type="button"
        disabled={!selectedType}
        onClick={() => setFilterSelectedType(v => !v)}
        title={selectedType ? `Show only ${selectedTypeLabel} objects` : 'Select an object to filter by type'}
        style={{
          width: '100%',
          border: `1px solid ${typeFiltered ? 'var(--accent)' : 'var(--border)'}`,
          borderRadius: 7,
          padding: '6px 8px',
          background: typeFiltered ? 'color-mix(in srgb, var(--accent) 12%, var(--surface2))' : 'var(--surface2)',
          color: selectedType ? (typeFiltered ? 'var(--accent)' : 'var(--text)') : 'var(--faint)',
          cursor: selectedType ? 'pointer' : 'not-allowed',
          fontFamily: 'inherit',
          fontSize: 11,
          fontWeight: typeFiltered ? 700 : 600,
          textAlign: 'left',
        }}
      >
        {typeFiltered ? `Showing ${selectedTypeLabel} only` : selectedType ? `Only show ${selectedTypeLabel}` : 'Only show selected type'}
      </button>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
        {/* Groups first */}
        {visibleGroups.map(group => {
          const groupObjs = groupedMap[group.id] || []
          const isCollapsed = collapsedGroups[group.id]
          const isDraggingThisGroup = draggingId === `group:${group.id}`
          const showBeforeGroup = dropTarget?.id === group.id && dropTarget.position === 'before' && dropTarget.isGroup
          const showAfterGroup = dropTarget?.id === group.id && dropTarget.position === 'after' && dropTarget.isGroup
          const showIntoGroup = dropTarget?.id === group.id && dropTarget.position === 'into'

          return (
            <div key={group.id} style={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
              <DropLine show={showBeforeGroup} />
              {/* Group header */}
              <div
                draggable
                onDragStart={e => { setDraggingId(`group:${group.id}`); e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', `group:${group.id}`) }}
                onDragOver={e => {
                  e.preventDefault(); e.stopPropagation()
                  const rect = e.currentTarget.getBoundingClientRect()
                  const y = e.clientY - rect.top
                  const pos = y < rect.height * 0.3 ? 'before' : y > rect.height * 0.7 ? 'after' : 'into'
                  setDropTarget({ id: group.id, position: pos, isGroup: true })
                }}
                onDrop={e => { e.preventDefault(); e.stopPropagation(); if (draggingId?.startsWith('group:')) handleGroupDrop(group.id, dropTarget?.position || 'before'); else handleDropIntoGroup(group.id) }}
                onDragEnd={() => { setDraggingId(null); setDropTarget(null) }}
                style={{
                  display: 'grid', gridTemplateColumns: '18px 1fr auto', gap: 4, alignItems: 'center',
                  padding: '5px 7px', borderRadius: 7, cursor: 'grab',
                  opacity: isDraggingThisGroup ? 0.4 : 1,
                  background: showIntoGroup ? 'color-mix(in srgb, var(--accent) 18%, var(--surface2))' : 'var(--surface2)',
                  border: `1px solid ${showIntoGroup ? 'var(--accent)' : 'var(--border)'}`,
                }}
              >
                <button
                  onClick={e => { e.stopPropagation(); setCollapsedGroups(prev => ({ ...prev, [group.id]: !isCollapsed })) }}
                  style={{ ...layerBtnStyle, fontSize: 10, width: 18, height: 18, display: 'grid', placeItems: 'center', border: '1px solid var(--border)', borderRadius: 3, background: 'var(--surface)' }}
                >
                  {isCollapsed ? '▶' : '▼'}
                </button>
                {renamingGroupId === group.id ? (
                  <input
                    autoFocus
                    value={renameVal}
                    onChange={e => setRenameVal(e.target.value)}
                    onBlur={saveGroupRename}
                    onKeyDown={e => { if (e.key === 'Enter') saveGroupRename(); if (e.key === 'Escape') setRenamingGroupId(null) }}
                    onClick={e => e.stopPropagation()}
                    style={{ ...inputStyle, fontSize: 16, padding: '2px 5px', height: 22 }}
                  />
                ) : (
                  <span
                    onDoubleClick={e => { e.stopPropagation(); setRenamingGroupId(group.id); setRenameVal(group.name || '') }}
                    style={{ fontSize: 11, fontWeight: 700, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', userSelect: 'none' }}
                  >
                    {group.name || 'Group'} <span style={{ fontWeight: 400, color: 'var(--muted)' }}>({groupObjs.length})</span>
                  </span>
                )}
                <div style={{ display: 'flex', gap: 2, alignItems: 'center' }}>
                  <button onClick={e => { e.stopPropagation(); toggleGroupVisible(group.id) }} title={group.visible === false ? 'Show group' : 'Hide group'} style={{ ...layerBtnStyle, color: group.visible === false ? 'var(--faint)' : 'var(--muted)' }}>{group.visible === false ? '○' : '●'}</button>
                  <button onClick={e => { e.stopPropagation(); if (window.confirm('Delete group? Objects will be ungrouped.')) deleteGroup(group.id) }} title="Delete group" style={{ ...layerBtnStyle, color: 'var(--danger)' }}>×</button>
                </div>
              </div>

              {/* Group objects */}
              {!isCollapsed && groupObjs.map(o => {
                const isSelected = selectedIds.includes(o.id)
                const name = o.properties?.name || o.properties?.text || o.properties?.title || o.properties?.stampId || o.type
                const icon = TYPE_ICONS[o.type] || '□'
                const color = TYPE_COLORS[o.type] || 'var(--muted)'
                const isDragging = draggingId === o.id
                const showBefore = dropTarget?.id === o.id && dropTarget.position === 'before' && !dropTarget.isGroup
                const showAfter = dropTarget?.id === o.id && dropTarget.position === 'after' && !dropTarget.isGroup
                return (
                  <div key={o.id} style={{ display: 'flex', flexDirection: 'column', gap: 1, paddingLeft: 16 }}>
                    <DropLine show={showBefore} />
                    <div
                      draggable
                      onDragStart={e => { setDraggingId(o.id); e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', o.id) }}
                      onDragOver={e => {
                        e.preventDefault(); e.stopPropagation()
                        const rect = e.currentTarget.getBoundingClientRect()
                        const y = e.clientY - rect.top
                        setDropTarget({ id: o.id, position: y < rect.height / 2 ? 'before' : 'after', isGroup: false })
                      }}
                      onDrop={e => { e.preventDefault(); e.stopPropagation(); handleObjectDrop(o.id, group.id, dropTarget?.position || 'before') }}
                      onDragEnd={() => { setDraggingId(null); setDropTarget(null) }}
                      onClick={() => { setMode('select'); setSelectedIds([o.id]) }}
                      style={{
                        display: 'grid', gridTemplateColumns: '22px 1fr auto', gap: 4, alignItems: 'center',
                        padding: '4px 7px', borderRadius: 6, cursor: 'grab',
                        opacity: isDragging ? 0.35 : 1,
                        background: isSelected ? 'color-mix(in srgb, var(--accent) 14%, var(--surface2))' : 'transparent',
                        border: `1px solid ${isSelected ? 'var(--accent)' : 'transparent'}`,
                      }}
                    >
                      <span style={{ width: 20, height: 20, borderRadius: 4, background: color, display: 'grid', placeItems: 'center', fontSize: 10, color: '#fff', flexShrink: 0, fontWeight: 700 }}>{icon}</span>
                      <span style={{ fontSize: 11, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{String(name).slice(0, 20)}</span>
                      <div style={{ display: 'flex', gap: 2, alignItems: 'center' }}>
                        <button onClick={e => { e.stopPropagation(); toggleVisible(o.id) }} title={o.visible === false ? 'Show' : 'Hide'} style={{ ...layerBtnStyle, color: o.visible === false ? 'var(--faint)' : 'var(--muted)' }}>{o.visible === false ? '○' : '●'}</button>
                        <button onClick={e => { e.stopPropagation(); removeFromGroup(o.id) }} title="Remove from group" style={{ ...layerBtnStyle, fontSize: 10 }}>⤴</button>
                        <button onClick={e => { e.stopPropagation(); deleteOne(o.id) }} title="Delete" style={{ ...layerBtnStyle, color: 'var(--danger)' }}>×</button>
                      </div>
                    </div>
                    <DropLine show={showAfter} />
                  </div>
                )
              })}
              <DropLine show={showAfterGroup} />
            </div>
          )
        })}

        {/* Ungrouped objects */}
        {ungrouped.length > 0 && groups.length > 0 && (
          <div style={{ fontSize: 10, color: 'var(--muted)', padding: '6px 4px 2px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Ungrouped</div>
        )}
        {ungrouped.map((o, idx) => {
          const isSelected = selectedIds.includes(o.id)
          const name = o.properties?.name || o.properties?.text || o.properties?.title || o.properties?.stampId || o.type
          const icon = TYPE_ICONS[o.type] || '□'
          const color = TYPE_COLORS[o.type] || 'var(--muted)'
          const isDragging = draggingId === o.id
          const showBefore = dropTarget?.id === o.id && dropTarget.position === 'before' && !dropTarget.isGroup
          const showAfter = dropTarget?.id === o.id && dropTarget.position === 'after' && !dropTarget.isGroup
          return (
            <div key={o.id} style={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
              <DropLine show={showBefore} />
              <div
                draggable
                onDragStart={e => { setDraggingId(o.id); e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', o.id) }}
                onDragOver={e => {
                  e.preventDefault(); e.stopPropagation()
                  const rect = e.currentTarget.getBoundingClientRect()
                  const y = e.clientY - rect.top
                  setDropTarget({ id: o.id, position: y < rect.height / 2 ? 'before' : 'after', isGroup: false })
                }}
                onDrop={e => { e.preventDefault(); e.stopPropagation(); handleObjectDrop(o.id, null, dropTarget?.position || 'before') }}
                onDragEnd={() => { setDraggingId(null); setDropTarget(null) }}
                onClick={() => { setMode('select'); setSelectedIds([o.id]) }}
                style={{
                  display: 'grid', gridTemplateColumns: '22px 1fr auto', gap: 4, alignItems: 'center',
                  padding: '5px 7px', borderRadius: 7, cursor: 'grab',
                  opacity: isDragging ? 0.35 : 1,
                  background: isSelected ? 'color-mix(in srgb, var(--accent) 14%, var(--surface2))' : 'var(--surface2)',
                  border: `1px solid ${isSelected ? 'var(--accent)' : 'var(--border)'}`,
                }}
              >
                <span style={{ width: 22, height: 22, borderRadius: 5, background: color, display: 'grid', placeItems: 'center', fontSize: 11, color: '#fff', flexShrink: 0, fontWeight: 700 }}>{icon}</span>
                <span style={{ fontSize: 11, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{String(name).slice(0, 22)}</span>
                <div style={{ display: 'flex', gap: 2, alignItems: 'center' }}>
                  <button onClick={e => { e.stopPropagation(); moveObjectInList(o.id, -1) }} title="Move up" style={layerBtnStyle} disabled={idx === 0}>↑</button>
                  <button onClick={e => { e.stopPropagation(); moveObjectInList(o.id, 1) }} title="Move down" style={layerBtnStyle} disabled={idx === ungrouped.length - 1}>↓</button>
                  <button onClick={e => { e.stopPropagation(); toggleVisible(o.id) }} title={o.visible === false ? 'Show' : 'Hide'} style={{ ...layerBtnStyle, color: o.visible === false ? 'var(--faint)' : 'var(--muted)' }}>{o.visible === false ? '○' : '●'}</button>
                  <button onClick={e => { e.stopPropagation(); deleteOne(o.id) }} title="Delete" style={{ ...layerBtnStyle, color: 'var(--danger)' }}>×</button>
                </div>
              </div>
              <DropLine show={showAfter} />
            </div>
          )
        })}
        {typeFiltered && displayedSorted.length === 0 && (
          <div style={{ color: 'var(--muted)', fontSize: 12, lineHeight: 1.5, padding: '8px 4px' }}>
            No {selectedTypeLabel.toLowerCase()} objects in this map.
          </div>
        )}
      </div>

      {groups.length > 0 && (
        <div style={{ fontSize: 11, color: 'var(--muted)', lineHeight: 1.5, marginTop: 4, padding: '6px 8px', background: 'var(--surface2)', borderRadius: 6 }}>
          Drag objects onto a group header to add them to that group.
        </div>
      )}
    </>
  )
}

// ─── Places Panel ──────────────────────────────────────────────────────────────

function PlacesPanel({ objects, selectedIds, setSelectedIds, setMode, setInspectorTab, project, isInteriorMap, setSelectedLocationId, territoryNoun = 'Region', territoryNounPlural = 'Regions' }) {
  const [filter, setFilter] = useState('all') // 'all' | 'location' | 'territory'
  const [search, setSearch] = useState('')

  const PLACE_TYPES = isInteriorMap ? ['territory'] : ['location', 'territory']
  const places = objects.filter(o => PLACE_TYPES.includes(o.type))
  const locations = places.filter(o => o.type === 'location')
  const territories = places.filter(o => o.type === 'territory')
  const activeFilter = isInteriorMap ? 'all' : filter

  const filtered = places.filter(o => {
    if (activeFilter !== 'all' && o.type !== activeFilter) return false
    if (search.trim()) {
      const name = (o.properties?.name || '').toLowerCase()
      return name.includes(search.trim().toLowerCase())
    }
    return true
  })

  function selectPlace(o) {
    setMode('select')
    setSelectedIds([o.id])
    setInspectorTab('object')
  }

  function openLinkedLocation(o) {
    const locId = o.linkedEntity?.entityId
    if (!locId) return
    setSelectedLocationId?.(locId)
    window.dispatchEvent(new CustomEvent('switch-section', { detail: { section: 'locations' } }))
  }

  if (!places.length) {
    return (
      <div style={{ color: 'var(--muted)', fontSize: 13, lineHeight: 1.6 }}>
        {isInteriorMap ? 'No rooms yet.' : `No locations or ${territoryNounPlural.toLowerCase()} yet.`}<br />{isInteriorMap ? 'Use the Room tool to mark rooms on your interior map.' : `Use the Location tool or draw a ${territoryNoun} to add places to your map.`}
      </div>
    )
  }

  return (
    <>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search places…"
          style={{ ...inputStyle, fontSize: 16, padding: '5px 8px' }}
        />
        <div style={{ display: 'grid', gridTemplateColumns: isInteriorMap ? '1fr' : 'repeat(3, 1fr)', gap: 4 }}>
          {(isInteriorMap
            ? [['all', `Rooms (${territories.length})`]]
            : [['all', `All (${places.length})`], ['location', `Locations (${locations.length})`], ['territory', `${territoryNounPlural} (${territories.length})`]]
          ).map(([val, label]) => (
            <button
              key={val}
              onClick={() => setFilter(val)}
              style={{
                padding: '4px 6px', fontSize: 10, borderRadius: 5, cursor: 'pointer',
                fontFamily: 'inherit', fontWeight: activeFilter === val ? 700 : 400,
                border: `1px solid ${activeFilter === val ? 'var(--accent)' : 'var(--border)'}`,
                background: activeFilter === val ? 'color-mix(in srgb, var(--accent) 14%, var(--surface2))' : 'var(--surface2)',
                color: activeFilter === val ? 'var(--accent)' : 'var(--muted)',
              }}
            >{label}</button>
          ))}
        </div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
        {filtered.length === 0 && (
          <div style={{ color: 'var(--muted)', fontSize: 12 }}>No results.</div>
        )}
        {filtered.map(o => {
          const name = o.properties?.name || o.type
          const isSelected = selectedIds.includes(o.id)
          const linkedLoc = o.linkedEntity?.entityType === 'location'
            ? (project.locations || []).find(l => l.id === o.linkedEntity.entityId) : null
          const typeColor = TYPE_COLORS[o.type] || 'var(--muted)'
          const typeIcon = TYPE_ICONS[o.type] || '□'

          return (
            <div
              key={o.id}
              onClick={() => selectPlace(o)}
              style={{
                display: 'flex', alignItems: 'flex-start', gap: 8, padding: '7px 9px',
                borderRadius: 7, cursor: 'pointer',
                background: isSelected ? 'color-mix(in srgb, var(--accent) 14%, var(--surface2))' : 'var(--surface2)',
                border: `1px solid ${isSelected ? 'var(--accent)' : 'var(--border)'}`,
              }}
            >
              <span style={{ width: 24, height: 24, borderRadius: 6, background: typeColor, display: 'grid', placeItems: 'center', fontSize: 12, color: '#fff', flexShrink: 0, fontWeight: 700, marginTop: 1 }}>{typeIcon}</span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{name || '(unnamed)'}</div>
                <div style={{ fontSize: 10, color: 'var(--muted)', marginTop: 1 }}>
                  {isInteriorMap ? 'Room indicator' : (o.type === 'location' ? 'Location marker' : territoryNoun)}
                  {!isInteriorMap && linkedLoc && <span style={{ color: 'var(--accent)' }}> · {linkedLoc.name}</span>}
                </div>
              </div>
              {!isInteriorMap && linkedLoc && (
                <button
                  onClick={e => { e.stopPropagation(); openLinkedLocation(o) }}
                  title="Open linked entry"
                  style={{ ...layerBtnStyle, fontSize: 13, color: 'var(--accent)', flexShrink: 0 }}
                >→</button>
              )}
            </div>
          )
        })}
      </div>

      {filtered.length > 0 && (
        <div style={{ fontSize: 11, color: 'var(--muted)', textAlign: 'center', paddingTop: 4 }}>
          Click {isInteriorMap ? 'a room' : 'a place'} to select it on the canvas
        </div>
      )}
    </>
  )
}

const layerBtnStyle = { background: 'none', border: 'none', cursor: 'pointer', color: 'var(--muted)', fontSize: 12, padding: '0 2px', fontFamily: 'inherit', lineHeight: 1 }

// ─── Map Inspector ────────────────────────────────────────────────────────────

function MapInspector({ activeMap, project, stylePreset, gridSettings, baseLayer = 'water', persistMeta, selectMap, deleteMap, renameMap, onOpenNewMap }) {
  const [renamingId, setRenamingId] = useState(null)
  const [renameVal, setRenameVal] = useState('')
  const maps = project.maps || []
  const isInterior = activeMap?.mapType === 'interior'

  function updateGrid(patch) { persistMeta({ gridSettings: { ...gridSettings, ...patch } }) }

  return (
    <>
      <div style={{ fontWeight: 700, fontSize: 13, color: 'var(--text)' }}>Style</div>
      <Field label="Visual style">
        <select value={stylePreset} onChange={e => persistMeta({ stylePreset: e.target.value })} style={inputStyle}>
          {STYLE_PRESETS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
        </select>
      </Field>
      {!isInterior && (
        <Field label="Base layer">
          <select value={baseLayer} onChange={e => persistMeta({ baseLayer: e.target.value })} style={inputStyle}>
            <option value="water">Open water — draw landmasses on top</option>
            <option value="land">Land — draw water on top</option>
          </select>
        </Field>
      )}

      <div style={{ fontWeight: 700, fontSize: 13, color: 'var(--text)', marginTop: 6 }}>Grid overlay</div>
      <label style={checkStyle}><input type="checkbox" checked={Boolean(gridSettings.enabled)} onChange={e => updateGrid({ enabled: e.target.checked })} /> Show grid</label>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
        <Field label="Type">
          <select value={gridSettings.type || 'square'} onChange={e => updateGrid({ type: e.target.value })} style={inputStyle}>
            <option value="square">Square</option><option value="hex">Hex</option>
          </select>
        </Field>
        <Field label="Size"><input type="number" value={gridSettings.size || 40} min={10} onChange={e => updateGrid({ size: Number(e.target.value) })} style={inputStyle} /></Field>
        <Field label="Opacity %"><input type="number" value={round((gridSettings.opacity || 0.28) * 100, 0)} min={5} max={90} onChange={e => updateGrid({ opacity: clamp(Number(e.target.value) / 100, 0.05, 0.9) })} style={inputStyle} /></Field>
        <Field label="Colour"><input type="color" value={gridSettings.color || '#5b4630'} onChange={e => updateGrid({ color: e.target.value })} style={{ ...inputStyle, height: 32, padding: 2 }} /></Field>
      </div>
      <label style={checkStyle}><input type="checkbox" checked={Boolean(gridSettings.snapToGrid)} onChange={e => updateGrid({ snapToGrid: e.target.checked })} /> Snap to grid</label>
      <Field label="Scale label"><input value={gridSettings.scale || ''} onChange={e => updateGrid({ scale: e.target.value })} placeholder="e.g. 1 square = 5 ft" style={inputStyle} /></Field>

      <div style={{ fontWeight: 700, fontSize: 13, color: 'var(--text)', marginTop: 6 }}>Maps</div>
      {maps.map(map => (
        <div key={map.id} style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
          {renamingId === map.id ? (
            <input autoFocus value={renameVal} onChange={e => setRenameVal(e.target.value)}
              onBlur={() => { if (renameVal.trim()) renameMap(map.id, renameVal.trim()); setRenamingId(null) }}
              onKeyDown={e => { if (e.key === 'Enter') { if (renameVal.trim()) renameMap(map.id, renameVal.trim()); setRenamingId(null) } if (e.key === 'Escape') setRenamingId(null) }}
              style={{ ...inputStyle, flex: 1, fontSize: 16 }} />
          ) : (
            <button onClick={() => selectMap(map.id)} onDoubleClick={() => { setRenamingId(map.id); setRenameVal(map.name || '') }}
              style={{ flex: 1, textAlign: 'left', background: map.id === activeMap.id ? 'var(--accent)' : 'var(--surface2)', color: map.id === activeMap.id ? '#fff' : 'var(--muted)', border: `1px solid ${map.id === activeMap.id ? 'var(--accent)' : 'var(--border)'}`, borderRadius: 6, padding: '5px 8px', fontSize: 12, cursor: 'pointer', fontFamily: 'inherit', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {map.name || 'Untitled'}
            </button>
          )}
          {maps.length > 1 && <button className="btn btn-secondary btn-sm" style={{ padding: '0 6px', minHeight: 26 }} onClick={() => { if (confirm('Delete this map?')) deleteMap(map.id) }}>×</button>}
        </div>
      ))}
      <button className="btn btn-primary btn-sm" style={{ fontSize: 12 }} onClick={onOpenNewMap}>+ New map</button>
    </>
  )
}

// ─── Modal ────────────────────────────────────────────────────────────────────

function MapModal({ modal, onClose, locConfig, setLocConfig, labelConfig, setLabelConfig, noteConfig, setNoteConfig, territoryConfig, setTerritoryConfig, locations, isCampaign, isInteriorMap, isLocalMap, territoryNoun = 'Region', onConfirm }) {
  const nounLower = territoryNoun.toLowerCase()
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)', display: 'grid', placeItems: 'center', zIndex: 999 }} onClick={e => { if (e.target === e.currentTarget) onClose() }}>
      <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 12, padding: 24, width: 380, display: 'flex', flexDirection: 'column', gap: 14, boxShadow: 'var(--shadow-md)' }}>
        <div style={{ fontWeight: 700, fontSize: 16, color: 'var(--text)' }}>
          {modal.kind === 'location' ? 'Place location' : modal.kind === 'label' ? 'Add label' : modal.kind === 'territory' ? `Name this ${nounLower}` : 'Add note'}
        </div>

        {modal.kind === 'location' && (
          <>
            <div style={{ fontSize: 12, color: 'var(--muted)', lineHeight: 1.45 }}>
              Link this marker to an existing worldbuilding location, or name a new one.
            </div>
            <Field label="Link to existing location">
              <select value={locConfig.linkToId} onChange={e => {
                const loc = locations.find(l => l.id === e.target.value)
                setLocConfig(c => ({ ...c, linkToId: e.target.value, name: loc?.name || c.name, createNew: false }))
              }} style={inputStyle}>
                <option value="">— no link —</option>
                {locations.map(l => <option key={l.id} value={l.id}>{l.name}</option>)}
              </select>
            </Field>
            <Field label={locConfig.linkToId ? 'Or create new location' : 'Name'}>
              <input value={locConfig.name} onChange={e => setLocConfig(c => ({ ...c, name: e.target.value, linkToId: '', createNew: true }))} placeholder={locConfig.linkToId ? 'Leave blank to use linked name' : 'Location name'} style={inputStyle} />
            </Field>
            <Field label="Marker icon">
              <select value={locConfig.markerIcon} onChange={e => setLocConfig(c => ({ ...c, markerIcon: e.target.value }))} style={inputStyle}>
                {LOCATION_ICON_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
              </select>
            </Field>
            <Field label="Icon size">
              <input type="number" value={locConfig.iconSize || DEFAULT_LOCATION_ICON_SIZE} min={8} max={240} onChange={e => setLocConfig(c => ({ ...c, iconSize: clamp(Number(e.target.value) || DEFAULT_LOCATION_ICON_SIZE, 8, 240) }))} style={inputStyle} />
            </Field>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
              <Field label="Icon colour">
                <input type="color" value={locConfig.fill || DEFAULT_LOCATION_FILL} onChange={e => setLocConfig(c => ({ ...c, fill: e.target.value }))} style={{ ...inputStyle, height: 34, padding: 3 }} />
              </Field>
              <Field label="Icon outline">
                <input type="color" value={locConfig.stroke || DEFAULT_LOCATION_STROKE} onChange={e => setLocConfig(c => ({ ...c, stroke: e.target.value }))} style={{ ...inputStyle, height: 34, padding: 3 }} />
              </Field>
            </div>
            <Field label="Label size">
              <input type="number" value={locConfig.labelFontSize || 18} min={8} max={96} onChange={e => setLocConfig(c => ({ ...c, labelFontSize: clamp(Number(e.target.value) || 18, 8, 96) }))} style={inputStyle} />
            </Field>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
              <Field label="Label colour">
                <input type="color" value={locConfig.labelColor || DEFAULT_LOCATION_LABEL_COLOR} onChange={e => setLocConfig(c => ({ ...c, labelColor: e.target.value }))} style={{ ...inputStyle, height: 34, padding: 3 }} />
              </Field>
              <Field label="Label outline">
                <input type="color" value={locConfig.labelOutlineColor || DEFAULT_LOCATION_LABEL_OUTLINE} onChange={e => setLocConfig(c => ({ ...c, labelOutlineColor: e.target.value }))} style={{ ...inputStyle, height: 34, padding: 3 }} />
              </Field>
            </div>
          </>
        )}

        {modal.kind === 'label' && (
          <>
            <Field label="Label text">
              <input autoFocus value={labelConfig.text} onChange={e => setLabelConfig(c => ({ ...c, text: e.target.value }))} placeholder="Your label text..." style={inputStyle} />
            </Field>
            <Field label="Font">
              <select value={labelConfig.fontFamily} onChange={e => setLabelConfig(c => ({ ...c, fontFamily: e.target.value }))} style={inputStyle}>
                {MAP_FONT_OPTIONS.map(f => <option key={f.value} value={f.value}>{f.label}</option>)}
              </select>
            </Field>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
              <Field label="Size"><input type="number" value={labelConfig.fontSize} min={10} onChange={e => setLabelConfig(c => ({ ...c, fontSize: Number(e.target.value) }))} style={inputStyle} /></Field>
              <Field label="Style">
                <select value={labelConfig.fontStyle} onChange={e => setLabelConfig(c => ({ ...c, fontStyle: e.target.value }))} style={inputStyle}>
                  <option value="normal">Regular</option><option value="italic">Italic</option>
                </select>
              </Field>
            </div>
          </>
        )}

        {modal.kind === 'note' && (
          <>
            <Field label="Title (optional)">
              <input autoFocus value={noteConfig.title} onChange={e => setNoteConfig(c => ({ ...c, title: e.target.value }))} placeholder="Note title..." style={inputStyle} />
            </Field>
            <Field label="Note body">
              <textarea value={noteConfig.body} onChange={e => setNoteConfig(c => ({ ...c, body: e.target.value }))} placeholder="Write your note here..." rows={4} style={{ ...inputStyle, resize: 'vertical', minHeight: 80 }} />
            </Field>
            <label style={checkStyle}>
              <input type="checkbox" disabled={Boolean(noteConfig.gmOnly)} checked={noteConfig.visibility === 'public' && !noteConfig.gmOnly} onChange={e => setNoteConfig(c => ({ ...c, visibility: e.target.checked ? 'public' : 'private' }))} /> Include title marker in PNG exports
            </label>
            {isCampaign && (
              <label style={checkStyle}>
                <input type="checkbox" checked={Boolean(noteConfig.gmOnly)} onChange={e => setNoteConfig(c => ({ ...c, gmOnly: e.target.checked, ...(e.target.checked ? { visibility: 'private' } : {}) }))} /> GM only
              </label>
            )}
          </>
        )}

        {modal.kind === 'territory' && (
          <>
            <div style={{ fontSize: 12, color: 'var(--muted)', lineHeight: 1.45 }}>
              {isInteriorMap
                ? 'Name this room. It will appear as a local label on this interior map.'
                : `Name this ${nounLower}. It will appear as a label on the map and can create an entry in your worldbuilding locations.`}
            </div>
            <Field label={`${territoryNoun} name`}>
              <input autoFocus value={territoryConfig.name} onChange={e => setTerritoryConfig(c => ({ ...c, name: e.target.value }))} placeholder={isInteriorMap ? 'e.g. Library' : isLocalMap ? 'e.g. Market Square' : territoryNoun === 'Kingdom' ? 'e.g. Kingdom of Aurethos' : 'e.g. The Northern Reaches'} style={inputStyle} />
            </Field>
            <Field label={`${territoryNoun} colour`}>
              <input type="color" value={territoryConfig.fill} onChange={e => setTerritoryConfig(c => ({ ...c, fill: e.target.value }))} style={{ ...inputStyle, height: 36, padding: 3, cursor: 'pointer' }} />
            </Field>
            {!isInteriorMap && (
              <>
                <Field label="Link to existing location (optional)">
                  <select value={territoryConfig.linkToId} onChange={e => setTerritoryConfig(c => ({ ...c, linkToId: e.target.value, createNewLocation: false }))} style={inputStyle}>
                    <option value="">— none —</option>
                    {locations.map(l => <option key={l.id} value={l.id}>{l.name}</option>)}
                  </select>
                </Field>
                <label style={checkStyle}>
                  <input type="checkbox" checked={Boolean(territoryConfig.createNewLocation)} onChange={e => setTerritoryConfig(c => ({ ...c, createNewLocation: e.target.checked, linkToId: '' }))} />
                  {' '}Create a new location entry for this {nounLower}
                </label>
              </>
            )}
          </>
        )}

        <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 4 }}>
          <button className="btn btn-secondary btn-sm" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary btn-sm" disabled={modal.kind === 'label' && !labelConfig.text.trim()} onClick={onConfirm}>
            {modal.kind === 'location' ? 'Place' : modal.kind === 'label' ? 'Place label' : modal.kind === 'territory' ? `Save ${nounLower}` : 'Place note'}
          </button>
        </div>
      </div>
    </div>
  )
}

// ─── View Mode Tooltip ────────────────────────────────────────────────────────

function ViewTooltip({ object, x, y, locations }) {
  const loc = object?.linkedEntity?.entityType === 'location'
    ? locations.find(l => l.id === object.linkedEntity.entityId)
    : null

  if (!loc) return null

  const name = object.properties?.name || loc.name
  const description = loc.description || ''
  const snippet = description.length > 120 ? description.slice(0, 120).trimEnd() + '…' : description

  // Keep tooltip in viewport
  const TOOLTIP_W = 260
  const OFFSET = 16
  const vpW = window.innerWidth
  const vpH = window.innerHeight
  const left = x + OFFSET + TOOLTIP_W > vpW ? x - TOOLTIP_W - OFFSET : x + OFFSET
  const top = y + OFFSET + 140 > vpH ? y - 140 - OFFSET : y + OFFSET

  return (
    <div
      style={{
        position: 'fixed',
        left,
        top,
        width: TOOLTIP_W,
        background: 'var(--surface)',
        border: '1px solid var(--border)',
        borderRadius: 10,
        padding: '12px 14px',
        boxShadow: '0 8px 32px rgba(0,0,0,0.45)',
        zIndex: 500,
        pointerEvents: 'none',
        display: 'flex',
        flexDirection: 'column',
        gap: 6,
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--accent)', flexShrink: 0 }} />
        <span style={{ fontWeight: 700, fontSize: 13, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{name}</span>
      </div>
      {loc.category && (
        <div style={{ fontSize: 10, fontWeight: 600, color: 'var(--accent)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{loc.category}</div>
      )}
      {snippet && (
        <div style={{ fontSize: 11, color: 'var(--muted)', lineHeight: 1.5 }}>{snippet}</div>
      )}
      <div style={{ fontSize: 10, color: 'var(--faint)', marginTop: 2 }}>Click to open entry</div>
    </div>
  )
}

// ─── Small UI helpers ─────────────────────────────────────────────────────────

function Field({ label, children }) {
  return (
    <label style={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
      <span style={{ fontSize: 11, fontWeight: 600, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>{label}</span>
      {children}
    </label>
  )
}

const inputStyle = {
  width: '100%', border: '1px solid var(--border)', background: 'var(--surface2)', color: 'var(--text)',
  borderRadius: 6, padding: '6px 9px', fontFamily: 'inherit', fontSize: 16, boxSizing: 'border-box',
}

function tabStyle(active) {
  return {
    padding: '5px 8px', borderRadius: 6, border: 'none', cursor: 'pointer', fontSize: 12, fontFamily: 'inherit', fontWeight: active ? 700 : 400,
    background: active ? 'var(--accent)' : 'transparent', color: active ? '#fff' : 'var(--muted)', transition: 'background 0.1s',
  }
}

const checkStyle = { display: 'flex', gap: 8, alignItems: 'center', fontSize: 12, color: 'var(--text)', cursor: 'pointer' }

// ─── Map schema parsing ───────────────────────────────────────────────────────

function migrateOldObject(o) {
  const meta = o.metadata || {}
  const { layerId, faces, points: metaPoints, ...rest } = meta

  // Convert old normalized-coord polygon faces to map-coordinate geometry
  if (faces?.length) {
    const face = faces[0] || []
    const pts = face.map(p => ({
      x: (o.x || 0) + (p.x - 0.5) * (o.width || 80),
      y: (o.y || 0) + (p.y - 0.5) * (o.height || 80),
    }))
    const geometry = pts.length >= 3 ? { type: 'polygon', points: pts } : null
    return { ...o, properties: rest, geometry }
  }

  // Convert old normalized-coord path points
  if (metaPoints?.length) {
    const pts = metaPoints.map(p => ({
      x: (o.x || 0) + (p.x - 0.5) * (o.width || 80),
      y: (o.y || 0) + (p.y - 0.5) * (o.height || 80),
    }))
    return { ...o, properties: rest, geometry: { type: 'path', points: pts } }
  }

  // Point objects (stamps, labels, locations, etc.)
  return { ...o, properties: rest, geometry: o.geometry || null }
}

function parseMapSchema(activeMap) {
  if (!activeMap) return { objects: [], layers: [], metadata: {}, width: MAP_W, height: MAP_H }
  const objects = (activeMap.mapObjects || []).map(o => {
    if (o.geometry && o.properties) return o  // already new format
    if (o.metadata) return migrateOldObject(o)  // old schema
    return { ...o, properties: o.properties || {}, geometry: o.geometry || null }
  })
  return {
    objects,
    layers: activeMap.mapLayers || [],
    metadata: activeMap.metadata || {},
    width: activeMap.width || MAP_W,
    height: activeMap.height || MAP_H,
  }
}

function normalizeGrid(settings, mapType) {
  const base = settings || {}
  const isInterior = mapType === 'interior'
  return {
    enabled: base.enabled ?? false,
    type: base.type || 'square',
    size: base.size || (isInterior ? 80 : 40),
    opacity: base.opacity ?? 0.28,
    color: base.color || '#5b4630',
    snapToGrid: base.snapToGrid ?? false,
    scale: base.scale || (isInterior ? '' : DEFAULT_GRID_SCALES[mapType] || ''),
  }
}
